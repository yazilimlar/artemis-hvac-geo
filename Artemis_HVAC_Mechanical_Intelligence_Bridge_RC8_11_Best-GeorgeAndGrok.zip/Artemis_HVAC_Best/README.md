# Artemis HVAC Mechanical Intelligence Bridge — RC8.11

**The definitive professional HVAC + construction intelligence platform**

George Oktem · Artemis Construction · New York · 2026

---

## What this is

A single-file, zero-dependency web application that unifies:

- **Parametric HVAC model** (DX rooftop units + chilled-water AHUs)
- **Live system explanation lab** (3D exploded views, refrigeration cycles, electrical, commissioning)
- **Quantity takeoff (QTO)** from geometry
- **Cost codes**, NYC union labor, crew planning
- **Earned Value Management (EVM)**, cashflow, risk
- **Field-to-cash** story: actuals → claims → payment lag → executive action
- **BIM-style 3D** with ViewCube, orbit, x-ray, flow particles
- **Sound studio**, cost heat maps, delay register, layout studio

All driven by one live parametric engine. Change outdoor air, hour, load, or unit type and every view updates.

---

## Quick start

1. Open `index.html` in a modern browser (Chrome 120+, Edge, Firefox, Safari).
2. Or serve it:

```bash
python3 -m http.server 8080
# then open http://localhost:8080
```

3. Click **System Lab** (top right) or **Enter live application**.

---

## System Lab (P49) — the heart of the HVAC intelligence

Open from:

- Header → **System Lab**
- Model menu → ⚙ System Lab
- HVAC Performance tab
- Command palette

### Sections

| Section | Content |
|---------|---------|
| **3D system** | 75-ton rooftop unit on curb + dunnage, supply drop, VAV, diffuser, zone sensor. Explode slider, x-ray casing, flow particles, isolate part, live labels. Switch DX ↔ CHW. |
| **Views** | Orbit (drag), pan (right-drag / Shift), zoom-to-cursor (wheel), double-click orbit about part. ViewCube (TOP/FRONT/RIGHT/…). Perspective, axonometric, 2D orthographic. Keys: H F A P T 1 3 7 E X L |
| **Flow schematic** | Animated air / refrigerant / CHW / electrical / controls layers. Live temperatures, CFM, pressures, amps, kW, PF. Economizer banner. |
| **Refrigeration cycle** | P-h chart with saturation dome, isotherms, cycle 1-2-3-4, animated state point. Superheat / subcooling / efficiency sliders. COP cooling & heating, compression ratio, discharge temp. |
| **Electrical** | One-line diagram, three-phase phasors, RLA / MCA / MOCP, winding temps, voltage imbalance. |
| **Compatibility** | Power, controls protocol, refrigerant, structure, duct pressure class, energy code checks. |
| **Commissioning (Cx)** | Standards + benchmarks + seeded test simulator. |
| **Duty cycles** | Design-day load profiles. |

Everything is driven by the live model hour, design-day load, outdoor air, tonnage and unit count.

---

## Core disciplines (live application)

- Geometry & parametric model
- QTO (duct LB, piping LF, insulation SF, devices)
- Cost codes (labor, material, subcontract, equipment, revenue)
- Schedule & cashflow
- EVM (CPI, SPI, forecast)
- Actuals, field reports, submittals, TAB
- Labor (NYC Locals 28 / 638 / 282 …)
- Risk register
- ASHRAE / executive psychrometrics & energy view

---

## Acceptance

Chrome 141 gate: **119 pass · 0 warn · 0 fail** (real mouse orbit, wheel zoom, ViewCube).

Headless (jsdom + Three stub): 113 pass · 4 warn · 0 fail.

Run in console:

```js
await ARTEMIS_ACCEPTANCE.run()
```

---

## Boundary

Representative engineering approximations for public demonstration.  
**Not** sealed design, not survey control, not official agency approval, not payment certification, not a substitute for manufacturer data, current code editions, or contract reconciliation.

---

## Files

| File | Purpose |
|------|---------|
| `index.html` | Complete self-contained application (RC8.11) |
| `CHANGELOG_RC8_11.md` | Release notes for System Lab (P49) |
| `artemis_acceptance_tests.js` | Full regression suite |
| `shots/` | Lab screenshots (3D, exploded, cycle, flow, electrical, Cx …) |

---

## Version history (selected)

- **RC8.11** — System Lab (exploded 3D, ViewCube, flow, refrigeration cycle, electrical, compatibility, commissioning, duty)
- **RC8.10** — Sound studio, Cost Heat Map, NYC union labor & crews, delay register, layout studio
- **RC8.5+** — Core QTO / Cost / EVM / Actuals / GIS / Dual Story Cockpit

---

Built with care for the people who design, install, balance, and own the systems.
