# Artemis HVAC Mechanical Intelligence Bridge — RC8.11

George Oktem · New York · 2026 · Artemis Construction

Built from RC8.10. It adds 3 version edits (`edits_rc811.json`) and patch P49 (`artemis_rc811_patch.js`). P1–P48 are preserved.

## Verification
| Check | Result |
|---|---|
| Chrome 141 acceptance gate (119 checks), with real mouse orbit, wheel zoom and a ViewCube click | **119 pass · 0 warn · 0 fail**, 0 console errors |
| Headless (jsdom + Three stub) | 113 pass · 4 warn (headless speed ×2, no 2D canvas, no Web Audio) · 0 fail |
| Engine numbers / goldens | unchanged — the Lab only reads the model |

## P49 · System Lab
A full-screen page. Open it from Model → ⚙ System Lab, "System Lab" on the story page, the HVAC Performance tab, or the palette. It follows the live model: hour (with a ▶ Day play), design-day load and outdoor air, tonnage and unit count. You can switch between a DX rooftop unit and a chilled-water AHU, and between cooling and heat-pump heating.

| Section | What it shows |
|---|---|
| **3D system** | One of the 11 rooftop units (75-ton nominal) on its curb and dunnage, the supply drop and main, a VAV terminal, a diffuser and a zone sensor — 20 part groups (CHW variant: chiller, pump, CHW piping). **Explode slider** and ▶ animation; **x-ray** casing; **labels** with overlap removal; **flow particles** (air and refrigerant, speed follows fan speed and stages); spinning fans; **isolate** a part. Click a part for its working principle, live values and standards. |
| **Views & controls** | Revit / CATIA-style: drag to orbit, right- or Shift-drag to pan, wheel to zoom to the cursor, double-click to orbit about a part, Home, Fit. Clickable **ViewCube** (TOP, FRONT, RIGHT, BACK, LEFT, BOTTOM, ISO). **3D perspective**, **axonometric (isometric)**, and **2D orthographic** plan, front, right, back and left views, with animated transitions. Turntable. Keys H F A P T 1 3 7 E X L. |
| **Flow schematic** | Animated 2D diagram with switchable air, refrigerant or chilled-water, electrical and controls layers. Dash speed follows flow. Live OA / MA / SA / RA / room temperatures, CFM, suction and head pressure, CHW °F and gpm, amps, kW, PF. Economizer banner. Working-principle notes. |
| **Refrigeration cycle** | Pressure–enthalpy chart with saturation dome, isotherms, cycle 1-2-3-4 and an animated state point. Superheat, subcooling and compressor-efficiency sliders. State table, COP (cooling and heating), compression ratio, discharge temperature, mass flow. Representative R-454B / R-410A-class fit: 45 °F → 144 psia, 117 °F → 411 psia. |
| **Electrical** | Animated one-line (utility → switchboard → feeder → fused disconnect → compressors, VFD fan, condenser fans, 24 V transformer). Live per-phase volts and amps, kW, kVA, PF, imbalance. Rotating **three-phase phasors** and waveforms. **NEC 430.250 FLA, 440.33 MCA, 440.22 MOCP** (default 169 A MCA / 200 A MOCP). Winding (class F), discharge, suction and head values. Unit and building-service voltage selectors. |
| **Compatibility** | 11 checks re-run on every choice: service voltage vs nameplate (±10 %), feeder and OCPD, voltage imbalance, controls protocol vs BAS front end, Guideline 36, A2L refrigerant and leak detection, roof psf and dunnage, duct pressure class vs fan static, economizer, efficiency class, Local Law 97 heating source. |
| **Testing & commissioning** | Nine stages on the schedule clock, in order: factory and submittal, duct leakage, controls point-to-point, refrigeration, electrical, start-up, TAB, functional performance, close-out. Each has its standard (AHRI, SMACNA, ASHRAE 15 / 111 / 202 / Guideline 0 / 36, NETA, IEEE 43, NEMA MG 1, AABC / NEBB / TABB, NYCECC C408, LL97), its acceptance benchmark, seeded measured results and pass / retest. Run any test early. |
| **Duty & heat cycles** | 24-hour design-day chart: outdoor temperature, compressor stages, starts per hour (≤ 6), economizer hours, unit kW, energy per unit and for the job, average COP. Heat-pump mode adds capacity derate, backup-heat hours and defrost windows. |

## Findings worth noting at default inputs
- **Duct pressure class:** class 2 in. w.g. against about 2.8 in. needed at the supply main → **FAIL**. Raise the main near the unit to class 3–4.
- **Roof load:** 44 psf against 30 psf → **WATCH**; steel dunnage is assumed.
- **Efficiency:** modeled EER at the 15:00 design hour is 9.6, against about 9.7 code minimum at AHRI conditions → **WATCH**. Confirm with certified data.

## Boundary
These are representative engineering approximations for a public demonstration. They are not sealed design, not a product selection, not official agency approval, and not a substitute for manufacturer data, the adopted code editions or contract reconciliation.
