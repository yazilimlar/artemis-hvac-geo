/* =====================================================================================
   ARTEMIS CONSTRUCTION — ACCEPTANCE TESTS (regression gate, RC8.11)
   George Oktem · New York · 2026 · Artemis Construction

   Run in the browser console on the built HTML:
       await ARTEMIS_ACCEPTANCE.run()          // prints a table, returns {pass,warn,fail,rows}
   or headless:  node tools/run_headless.js BUILD.html --tests artemis_acceptance_tests.js

   FAIL = must fix before handoff. WARN = allowed only with a written reason in the change log.
   The suite restores inputs and data mode when it finishes.
   ===================================================================================== */
(function(){
  'use strict';
  const GOLDEN_DEFAULT={"version":"RC8.5","inputs":"18ff1cd8","duration":252,"subtotal":9038864,"revenue":11994772,"ductLbs":71442,"equipEA":11,"finalCash":1998308};
  const BOUNDARY=['Not sealed design','not survey control','not official agency approval','not payment certification','not a substitute for contract reconciliation'];
  const COMPANY='Artemis Construction';
  const GOLDEN_UNION={"version":"RC8.5","inputs":"18ff1cd8","duration":142,"subtotal":9221520,"revenue":11735082,"ductLbs":71442,"equipEA":11,"finalCash":1973961};
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  const $=id=>document.getElementById(id);

  async function run(){
    const rows=[];
    const add=(area,label,status,note)=>rows.push({area,label,status,note:String(note??'')});
    const check=(area,label,pass,note,soft)=>add(area,label,pass?'PASS':(soft?'WARN':'FAIL'),note);
    const saved={};
    ['tonnage','condSF'].forEach(id=>{if($(id))saved[id]=$(id).value;});
    const savedMode=window.RC8_DATA?.mode||'demo-plan';
    const setInput=(id,v)=>{const el=$(id);if(el)el.value=String(v);};
    try{
      /* ---------- identity & boundaries */
      const v=window.ARTEMIS_VERSION||{};
      check('Identity','ARTEMIS_VERSION record present',!!v.version,v.version);
      check('Identity','Company is Artemis Construction',(v.company===COMPANY)||document.body.textContent.includes(COMPANY),v.company||'from page text');
      check('Identity','Retired company name absent',!new RegExp('IPC'+' Resil'+'iency','i').test(document.documentElement.outerHTML),'retired name');
      const body=document.body.textContent||'';
      const miss=BOUNDARY.filter(s=>!body.includes(s));
      check('Boundary','Five public-safe phrases present',!miss.length,miss.join(' · ')||'all present');
      const patches=(window.ARTEMIS_PATCHES||[]).flatMap(p=>p.applied);
      const needed=Array.from({length:49},(_,i)=>'P'+(i+1));
      check('Patches','P1–P49 applied',needed.every(p=>patches.includes(p)),needed.filter(p=>!patches.includes(p)).join(',')||patches.length+' patches');

      /* ---------- DOM integrity */
      const ids=[...document.querySelectorAll('[id]')].map(e=>e.id);
      const dups=[...new Set(ids.filter((x,i)=>ids.indexOf(x)!==i))];
      check('DOM','No duplicate element IDs',!dups.length,dups.join(', ')||ids.length+' ids');
      const tabs=[...document.querySelectorAll('#tabs .tab')];
      check('DOM','Every tab has its page',tabs.every(t=>$(t.dataset.t)),tabs.length+' tabs');
      const km=(window.ARTEMIS_KEYMAP||[]).map(k=>k.key+(k.shift?'+shift':''));
      check('Keyboard','Keymap has no duplicate bindings',km.length===new Set(km).size,km.length+' bindings');

      /* ---------- engine self-test & golden */
      const st=window.ARTEMIS_SELFTEST?.run?.()||[];
      const stFail=st.filter(r=>r.status!=='PASS');
      check('Engine','ARTEMIS_SELFTEST all PASS',st.length&&!stFail.length,stFail.map(r=>r.label).join('; ')||st.length+' checks');
      if(window.RC8_DATA&&RC8_DATA.mode!=='demo-plan')window.generateRC8Scenario?.('demo-plan');
      window.renderControlSystem?.(false);
      const gate=($('controlDecision')?.textContent||'').trim();
      check('Controls','Default demo is not on HOLD',!/HOLD/.test(gate),gate||'no gate');
      check('Risk','Default P80 within bid (contingency not double-counted)',window.ARTEMIS_RISK&&ARTEMIS_RISK.p80<=E.revenue,window.ARTEMIS_RISK?`${money(ARTEMIS_RISK.p80)} vs ${money(E.revenue)}`:'no risk');
      const LB=window.ARTEMIS_LABOR;
      check('RC8.8 Labor','Default labor basis is NYC union',LB&&LB.LAB.basis==='union'&&E.laborBasis==='union',E.laborBasis||'legacy');
      if(!String(GOLDEN_DEFAULT.inputs).startsWith('__')){
        if(LB){LB.LAB.basis='legacy';recalcAll(false);}
        const cmp=window.ARTEMIS_SELFTEST.compare(GOLDEN_DEFAULT);
        if(LB){LB.LAB.basis='union';recalcAll(false);}
        if(cmp.status==='SKIP')add('Engine','Golden snapshot (default inputs)','WARN','inputs differ from default — golden not comparable');
        else check('Engine','Legacy-basis golden snapshot (RC8.5 default) MATCH',cmp.status==='MATCH',cmp.status==='MATCH'?'no drift':cmp.diffs.map(d=>`${d.field} ${d.golden}→${d.now}`).join('; '),true);
        if(GOLDEN_UNION){const c2=window.ARTEMIS_SELFTEST.compare(GOLDEN_UNION);
          check('Engine','Union-basis golden snapshot (RC8.8 default) MATCH',c2.status==='MATCH',c2.status==='MATCH'?'no drift':(c2.diffs||[]).map(d=>`${d.field} ${d.golden}→${d.now}`).join('; ')||c2.reason,true);}
      }

      /* ---------- synchronous recalc contract */
      setInput('condSF',140000);const t0=performance.now();recalcAll();const dt=performance.now()-t0;
      check('Contract','recalcAll() is synchronous',G.condSF===140000,'G.condSF='+G.condSF);
      check('Performance','recalcAll() under 600 ms',dt<600,Math.round(dt)+' ms',true);
      setInput('condSF',saved.condSF||120000);recalcAll();

      /* ---------- model ↔ QTO agreement across tonnage */
      const has3D=typeof THREE!=='undefined'&&typeof SEL3D!=='undefined'&&SEL3D.dyn.length>0;
      for(const tons of [300,850,1200]){
        setInput('tonnage',tons);recalcAll();
        const meshes=has3D?SEL3D.dyn.filter(o=>o.userData.dyn==='EQUIP').length:null;
        if(has3D)check('Model↔QTO',`Equipment meshes = QTO at ${tons} tons`,meshes===G.equipEA,`${meshes} meshes vs ${G.equipEA} EA`);
        else add('Model↔QTO',`Equipment meshes = QTO at ${tons} tons`,'WARN','Three.js not loaded — 3D not testable here');
      }
      setInput('tonnage',saved.tonnage||850);recalcAll();

      /* ---------- unit truth in the schedule */
      if(typeof window.renderSequenceStory==='function')window.renderSequenceStory();
      const txt=$('schedTable')?.textContent||'';
      const wrongUnits=ACTS.filter(a=>a.unit!=='LF'&&(a.kind==='linear'||a.kind==='discrete')).filter(a=>!txt.includes(' '+a.unit+'/d'));
      check('Units','Schedule rates use each activity’s own unit',!wrongUnits.length,wrongUnits.map(a=>a.code).join(', ')||'ok');
      const lfRows=ACTS.filter(a=>a.unit==='LF'&&(a.kind==='linear'||a.kind==='discrete')).length;
      const lfShown=(txt.match(/ LF\/d/g)||[]).length;
      check('Units','“LF/d” appears only on LF activities',lfShown<=lfRows,`${lfShown} shown · ${lfRows} LF activities`);


      /* ---------- RC8.6: M3 header */
      const header=document.querySelector('#app>header');
      const top=[...header.children].filter(el=>el.matches('button,select,.artMenu,.rc8ModePill'));
      check('M3 Header','Top-level header controls ≤ 9',top.length<=9,top.length+' controls');
      const oldIds=['btnLeft','btnRight','btnNight','spaceStyle','btnRecalc','btnSat','btnTutorial','btnPresent','btnNarrative','btnRC83FieldClaims','btnOfflineQA','btnSafeView','btnFit100','btnExecRoom','btnDEPStandards','btnShotMode','btnShotDeck','btnCaptureStudio','btnVideoDemo','btnControls','btnRC7QA','btnHandoff'];
      const lost=oldIds.filter(id=>!$(id)||!header.contains($(id)));
      check('M3 Header','Every original header control still present',!lost.length,lost.join(',')||oldIds.length+' controls');

      /* ---------- RC8.6: M2 vocabulary */
      const clone=document.body.cloneNode(true);clone.querySelectorAll('script,style,textarea,noscript').forEach(n=>n.remove());
      const vis=clone.textContent;
      const banned=['chainage','Utility Standards','pipe LF','Planned pipe','STA 0+'].filter(w=>vis.includes(w));
      check('M2 Vocabulary','No sewer-era terms in page text',!banned.length,banned.join(', ')||'clean');

      /* ---------- RC8.6: M4 single risk engine */
      recalcAll();window.renderNarCockpit?.();
      const p80=window.ARTEMIS_RISK?.p80,note=$('narRiskNote')?.textContent||'';
      check('M4 Risk','Cockpit P80 = shared risk engine P80',!!p80&&note.includes('$'+(p80/1e6).toFixed(2)+'M'),p80?money(p80):'no ARTEMIS_RISK');

      /* ---------- claims & cash */
      window.RC83_applyScenario?.('demo-claims-payment-lag');await sleep(250);
      const cash=cashSeries();
      check('Cash','Claim-driven final cash is positive',cash.finalCash>0,money(cash.finalCash));
      check('Cash','Cash identity holds',Math.abs(cash.cumIn[cash.horizon-1]-cash.cumOut[cash.horizon-1]-cash.finalCash)<1,'cumIn−cumOut');
      window.renderActualsStudio?.();await sleep(50);
      check('Claims','Bulletin disclosure shown in payment-lag mode',!!document.querySelector('.rc851-bulletin-note'),'P19');

      /* ---------- RC8.6: M5 change orders (payment-lag scenario is active here) */
      const co=window.ARTEMIS_CO?.summary?.()||{count:0};
      check('M5 Change orders','Bulletins carried as change orders',co.count===4,co.count+' change orders');
      check('M5 Change orders','Revenue = base + approved CO only',Math.abs(E.revenue-(E.baseRevenue+co.approved))<1,`${money(E.baseRevenue)} + ${money(co.approved)} = ${money(E.revenue)}`);
      check('M5 Change orders','Pending / disputed CO value not in revenue',co.pending>0&&Math.abs(E.revenue-E.baseRevenue-co.approved)<1,`${money(co.pending)} pending · ${money(co.disputed)} disputed`);
      const rec=window.RC8_API?.reconciliation?.()||[];
      const nb=rec.find(r=>r.label==='Claims without field backup'),cor=rec.find(r=>r.label==='Change orders awaiting approval or in dispute');
      check('M5 Change orders','COs excluded from base-contract backup check',nb&&nb.status!=='ACTION REQUIRED',nb?nb.status+' — '+nb.note:'missing');
      check('M5 Change orders','CO approval check reported',!!cor&&cor.status==='WATCH',cor?cor.note:'missing');
      const bu=E.rows.reduce((s,r)=>s+actCategories(r.id).eac,0),evE=evmSeries().eac;
      check('P32 Forecast','Bottom-up EAC = EVM EAC',Math.abs(bu-evE)<2,`${money(bu)} vs ${money(evE)}`);
      const zr=rec.find(r=>r.label==='Zone ductwork quantity vs zone model quantity');
      check('M2 Units','Zone reconciliation uses ductwork LB',!!zr,zr?zr.note:'missing');
      const rev1=E.revenue;window.RC83_applyScenario?.('demo-claims-payment-lag');await sleep(150);
      check('M5 Change orders','Scenario reload is deterministic',Math.abs(E.revenue-rev1)<0.01,money(E.revenue));

      /* ---------- RC8.6: M1 table paging */
      window.renderActualsStudio?.();
      const fr=$('fieldReportsTable')?.querySelectorAll('tbody tr').length||0;
      check('M1 Performance','Field table pages at 100 rows',fr<=100&&(RC8_DATA.fields.length<=100||!!$('fieldReportsTable')?.querySelector('[data-rows-more]')),`${fr} of ${RC8_DATA.fields.length} rows`);

      EXEC.series=null;const ex=execBuildSeries(true);
      check('Executive','Executive billing reaches > 50% of bid',ex[ex.length-1].billed>E.revenue*.5,money(ex[ex.length-1].billed));

      /* ---------- risk */
      runRisk();const p1=window.ARTEMIS_RISK?.p80;runRisk();const p2=window.ARTEMIS_RISK?.p80;
      check('Risk','Monte Carlo reproducible',p1&&p1===p2,money(p1||0));

      /* ---------- playback performance */
      const t1=performance.now();for(let d=1;d<=30;d++)setSimDay(d);const pt=performance.now()-t1;
      check('Performance','30 playback days under 3 s',pt<3000,Math.round(pt)+' ms',true);


      /* ---------- RC8.6: S5 run links, C1 tabs, Fourier wordmark */
      if(window.ARTEMIS_RUN){
        const before=window.ARTEMIS_SELFTEST.snapshot(),param=ARTEMIS_RUN.toParam();
        setInput('tonnage',1200);recalcAll();
        ARTEMIS_RUN.apply(ARTEMIS_RUN.decode(param));
        const after=window.ARTEMIS_SELFTEST.snapshot();
        check('S5 Run link','Run link restores identical state',JSON.stringify(before)===JSON.stringify(after),`${param.length} chars`);
      }else add('S5 Run link','Run link API present','FAIL','ARTEMIS_RUN missing');
      const tl=$('tabs');
      check('C1 Accessibility','Deck tabs expose tablist / tab / aria-selected',tl?.getAttribute('role')==='tablist'&&[...tl.querySelectorAll('.tab')].every(t=>t.getAttribute('role')==='tab'&&t.hasAttribute('aria-selected')),'ARIA roles');
      const wm=window.ARTEMIS_WORDMARK?.state;
      if(wm&&wm.terms)check('Wordmark','Fourier wordmark built',wm.terms.length===wm.N,`${wm.terms.length} rotating vectors`);
      else add('Wordmark','Fourier wordmark built',$('fourierWordmark')?'WARN':'FAIL',$('fourierWordmark')?'canvas 2D not available here (headless)':'canvas missing');

      /* ---------- RC8.7: HVAC building-section hero */
      const hero=document.querySelector('.narFeedSpine svg');
      const ht=hero?hero.textContent+' '+(hero.getAttribute('aria-label')||''):'';
      check('RC8.7 Hero','Hero is an HVAC building section (not a sewer profile)',!!hero&&/CEILING-PLENUM/.test(ht)&&!/DATUM|ROOF EL\.|INVERT|MANHOLE/i.test(ht),hero?'building section':'hero svg missing');
      const st6=['MODEL / BIM','QTO','COST','EVM','FIELD','ASHRAE'].filter(x=>!ht.includes(x));
      check('RC8.7 Hero','Source model feeds six stations',!st6.length,st6.join(', ')||'six stations');
      check('RC8.7 Hero','Rooftop plant, riser and floors drawn above grade',['RTU-1','AHU-1','CHILLER','RISER','L6'].every(x=>ht.includes(x)),'roof · riser · L1–L6');

      /* ---------- RC8.7: psychrometrics (ASHRAE Fundamentals, IP) */
      const H=window.ARTEMIS_HVAC;
      if(!H){add('RC8.7 HVAC','ARTEMIS_HVAC API present','FAIL','missing');}
      else{
        const ps=H.PSY.state({db:75,rh:.5,alt:0});
        check('RC8.7 Psychrometrics','75 °F / 50 % RH humidity ratio ≈ 64.6 gr/lb',Math.abs(ps.gr-64.6)<0.6,ps.gr.toFixed(2)+' gr/lb');
        check('RC8.7 Psychrometrics','Enthalpy ≈ 28.1 Btu/lb',Math.abs(ps.h-28.11)<0.15,ps.h.toFixed(2));
        check('RC8.7 Psychrometrics','Dew point ≈ 55.1 °F',Math.abs(ps.dp-55.12)<0.3,ps.dp.toFixed(2));
        check('RC8.7 Psychrometrics','Wet bulb ≈ 62.6 °F',Math.abs(ps.wb-62.55)<0.3,ps.wb.toFixed(2));
        check('RC8.7 Psychrometrics','Specific volume ≈ 13.68 ft³/lb',Math.abs(ps.v-13.679)<0.05,ps.v.toFixed(3));
        const sat=H.PSY.state({db:60,rh:1,alt:0});
        check('RC8.7 Psychrometrics','Saturated air: dew point = wet bulb = dry bulb',Math.abs(sat.dp-60)<0.2&&Math.abs(sat.wb-60)<0.2,`${sat.dp.toFixed(2)} / ${sat.wb.toFixed(2)}`);
        const nyc=H.PSY.state({db:91.6,wb:74.4,alt:0});
        check('RC8.7 Psychrometrics','NYC design 91.6/74.4 → RH ≈ 45 %',Math.abs(nyc.rh-.451)<0.02,(nyc.rh*100).toFixed(1)+' %');

        /* ---------- RC8.7: spaces, units, colour families */
        const sp=H.spaces();
        check('RC8.7 Spaces','One space per floor × zone',sp.length===G.floors*G.segments,`${sp.length} = ${G.floors} × ${G.segments}`);
        const sa=sp.reduce((a,x)=>a+x.area,0);
        check('RC8.7 Spaces','Space areas sum to conditioned SF',Math.abs(sa-G.condSF)<1,fmt(sa)+' SF');
        const capSum=sp.reduce((a,x)=>a+x.capTons,0);
        check('RC8.7 Spaces','Zone capacities sum to plant tonnage',Math.abs(capSum-G.tonnage)<0.01,capSum.toFixed(1)+' tons');
        const su=Object.assign({},H.HV.units);
        H.HV.units.area='m2';const m2=H.fmtU('area',10000);H.HV.units.area='acre';const ac=H.fmtU('area',43560);
        H.HV.units.vol='m3';const m3=H.fmtU('vol',1000);H.HV.units.vol='gal';const gal=H.fmtU('vol',1);H.HV.units.vol='L';const lit=H.fmtU('vol',1);
        Object.assign(H.HV.units,su);
        check('RC8.7 Units','Area and volume unit conversions',/^929\b/.test(m2)&&/^1\.000/.test(ac)&&/^28\b/.test(m3)&&/^7\b/.test(gal)&&/^28\b/.test(lit),[m2,ac,m3,gal,lit].join(' · '));
        const fams=['area','volume','load','temp','rh','submittal','tab','airflow'].filter(k=>!H.FAM[k]);
        check('RC8.7 Layers','Colour family for every 3D layer',!fams.length,fams.join(',')||Object.keys(H.FAM).length+' families');

        /* ---------- RC8.7: submittals and TAB follow the schedule clock */
        const d0=SIM.day;setSimDay(1);
        const sub1=H.submittals(),sp1=H.spaces();
        check('RC8.7 Submittals','Register present with status on day 1',sub1.length>=9&&sub1.every(r=>r.status),sub1.length+' submittals');
        check('RC8.7 TAB','No TAB results before test-and-balance',sp1.every(x=>x.tab==='Not tested'),'all Not tested');
        setSimDay(PLAN.duration);
        const subN=H.submittals(),spN=H.spaces();
        check('RC8.7 Submittals','All submittals decided at completion',subN.every(r=>/^Approved/.test(r.status)),subN.filter(r=>!/^Approved/.test(r.status)).map(r=>r.id+' '+r.status).join(', ')||'approved');
        check('RC8.7 TAB','Every space has a TAB result at completion',spN.every(x=>x.tab!=='Not tested'),['Pass','Rebalance','Fail'].map(k=>k+' '+spN.filter(x=>x.tab===k).length).join(' · '));
        setSimDay(d0);

        /* ---------- RC8.7: design day, limits, airflow */
        const c0=H.HV.cfmPct,h0=H.HV.hour;H.HV.hour=15;H.HV.cfmPct=150;
        const hiFail=H.limits().filter(r=>r.status==='fail').map(r=>r.name);H.HV.cfmPct=c0;
        const okRows=H.limits().filter(r=>r.status==='fail').length;H.HV.hour=h0;
        check('RC8.7 Airflow','Over-driving airflow trips velocity / noise limits',hiFail.some(n=>/velocity|air speed/i.test(n)),hiFail.join(' · ')||'none tripped');
        check('RC8.7 Airflow','Ideal sizing passes at design flow (15:00)',okRows===0,okRows+' fail');
        const dd=H.designDay();
        check('RC8.7 Energy','Design-day energy computed',dd&&dd.kwh>0&&dd.peakKW>0&&dd.hours.length===24,dd?`${fmt(dd.kwh)} kWh · ${fmt(dd.peakKW)} kW peak`:'null');
        const lim=H.limits();
        check('RC8.7 Limits','Operating-limit rows present',lim.length>=10&&lim.every(r=>/pass|watch|fail/.test(r.status)),lim.length+' rows · '+lim.filter(r=>r.status==='fail').length+' fail');
        const a=H.airStats();
        check('RC8.7 Airflow','Air-speed figures finite',a&&[a.vNeck,a.t50,a.vMain,a.occV,a.ach].every(Number.isFinite),a?`neck ${fmt(a.vNeck)} fpm · main ${fmt(a.vMain)} fpm`:'null');
        try{H.render();}catch(e){add('RC8.7 Tab','HVAC render','FAIL',e.message);}
        check('RC8.7 Tab','HVAC Performance deck tab present',!!$('tHVAC')&&!!$('hvPsyChart')&&!!$('hvAirCanvas'),'tHVAC · psychrometric chart · airflow canvas');
        if(typeof THREE!=='undefined'&&H.layer3d.group){
          check('RC8.7 3D','One translucent layer box per space',H.layer3d.boxes.length===sp.length,H.layer3d.boxes.length+' boxes');
          H.HV.layer='submittal';H.layer3d.apply();const vis=H.layer3d.group.visible;H.HV.layer='off';H.layer3d.apply();
          check('RC8.7 3D','Layer switches on and off',vis&&!H.layer3d.group.visible,'submittal → off');
        }else add('RC8.7 3D','3D layer built','WARN','Three.js not loaded here');
      }

      /* ---------- RC8.8: union labor engine */
      if(LB){
        const L=LB.LAB;
        const craftSum=E.rows.every(r=>!r.union||Math.abs(Object.values(r.union.crafts).reduce((a,c)=>a+c.hrs,0)-r.laborHrs)<0.5);
        check('RC8.8 Labor','Craft hours sum to activity labor hours',craftSum,'per activity');
        const cSum=E.rows.every(r=>!r.union||Math.abs(Object.values(r.union.crafts).reduce((a,c)=>a+c.cost,0)*({best:.96,base:1,worst:1.12,recovery:1.18}[val('scenario')]||1)-r.cat.L)<1);
        check('RC8.8 Labor','Craft cost sums to activity labor cost',cSum,'per activity');
        const dMH=Math.abs(E.laborHrs-E.legacy.laborHrs)/E.legacy.laborHrs;
        check('RC8.8 Labor','Man-hours preserved vs legacy (only stated factors)',dMH<.05,`${fmt(E.laborHrs)} vs ${fmt(E.legacy.laborHrs)} (${(dMH*100).toFixed(1)} %)`);
        const mp=LB.manpower();
        check('RC8.8 Labor','Peak tinknockers and steamfitters computed',mp.peak.L28>=1&&mp.peak.L638>=1&&mp.peak.L28S>0,`L28 ${Math.ceil(mp.peak.L28)} (+${Math.ceil(mp.peak.L28S)} shop) · L638 ${Math.ceil(mp.peak.L638)} · L282 ${Math.ceil(mp.peak.L282)}`);
        const hs=mp.days.reduce((a,o)=>a+Object.values(o).reduce((x,y)=>x+y,0),0);
        check('RC8.8 Labor','Manpower histogram populated',hs>0&&mp.weeks.length>0,`${mp.weeks.length} weeks · peak ${Math.ceil(mp.peakTotal)}`);
        const d0=PLAN.duration,c0=L.crews.A04;L.crews.A04=c0+2;recalcAll(false);const d1=PLAN.duration,w1=actWindow('A04');L.crews.A04=c0;recalcAll(false);
        check('RC8.8 Schedule','More duct crews shortens the crew-loaded schedule',d1<=d0&&w1.f<=actWindow('A04').f,`${d0} → ${d1} wd`);
        const lab0=E.rows.reduce((a,r)=>a+r.cat.L,0);L.otHrs=2;recalcAll(false);const mp2=LB.manpower(),lab1=E.rows.reduce((a,r)=>a+r.cat.L,0),d2=PLAN.duration;L.otHrs=0;recalcAll(false);
        check('RC8.8 Labor','Overtime adds premium time and shortens durations',mp2.split.premium>mp.split.premium&&lab1>lab0&&d2<=d0,`premium ${money(mp2.split.premium)} · ${d0}→${d2} wd`);
        L.basis='legacy';recalcAll(false);const dl=PLAN.duration;L.basis='union';recalcAll(false);
        check('RC8.8 Schedule','Union crew plan differs from legacy one-crew plan',dl!==PLAN.duration,`legacy ${dl} wd · union ${PLAN.duration} wd`);
        const st2=window.ARTEMIS_SELFTEST.run().filter(r=>r.status!=='PASS');
        check('RC8.8 Labor','Engine self-test passes under union basis',!st2.length,st2.map(r=>r.label).join('; ')||'all pass');
      }else add('RC8.8 Labor','ARTEMIS_LABOR present','FAIL','missing');
      /* ---------- RC8.8: delay register */
      const DL=window.ARTEMIS_DELAYS;
      if(DL){
        const reg=DL.register();
        check('RC8.8 Delays','Register covers every activity',reg.length===ACTS.length&&reg.every(x=>x.b&&x.w&&Number.isFinite(x.forecastF)),reg.length+' rows · '+reg.filter(x=>x.sev!=='ok').length+' watch/late');
        const rec=DL.recovery('A04');
        check('RC8.8 Delays','Recovery options re-run the schedule',rec.length===4&&rec[0].actDays<=0,rec.map(o=>`${o.label} ${o.actDays} wd`).join(' · '));
        openDeckTab('tSched');window.renderSequenceStory?.();
        check('RC8.8 Delays','Gantt shows baseline and selection overlays',document.querySelectorAll('#sequenceGantt .rc88Base').length===ACTS.length&&!!$('rc88Delays')&&!!document.querySelector('#sequenceGantt .rc88Sel'),document.querySelectorAll('#sequenceGantt .rc88Base').length+' baselines');
        DL.select('A07');check('RC8.8 Delays','Selecting an activity expands its detail',/Equipment Setting/.test($('rc88DelayDetail')?.textContent||''),'A07 detail');
        openDeckTab('tDash');
      }else add('RC8.8 Delays','ARTEMIS_DELAYS present','FAIL','missing');
      /* ---------- RC8.8: layout, trade, platform, story windows */
      const LY=window.ARTEMIS_LAYOUT;
      if(LY){LY.apply('deckRight');const dr=$('app').classList.contains('rc88DeckRight');LY.apply('default');
        check('RC8.8 Layout','Layout presets switch and reset',dr&&!$('app').classList.contains('rc88DeckRight')&&getComputedStyle(document.documentElement).getPropertyValue('--colL').trim()==='330px',Object.keys(LY.LAYOUTS).length+' presets');
        check('RC8.8 Layout','Drag splitters present',document.querySelectorAll('.rc88Split').length===2,'left · right');}
      const TR=window.ARTEMIS_TRADE;
      if(TR){openDeckTab('tERP');window.renderERP?.();TR.set('L28');
        const dim=document.querySelectorAll('#tERP .rc88Dim').length,hit=document.querySelectorAll('#tERP .rc88Hit').length;
        let m3='no 3D';if(typeof THREE!=='undefined'&&SEL3D.meshes.length){const pipe=SEL3D.meshes.find(m=>/\/HPIP$/.test(m.userData.elementId)),duct=SEL3D.meshes.find(m=>/\/DUCT$/.test(m.userData.elementId));m3=pipe&&duct&&pipe.material.opacity<=.07&&duct.material.opacity>.07?'ok':'bad';}
        await sleep(450);
        const dim2=document.querySelectorAll('#tERP .rc88Dim').length;
        check('RC8.8 Trade','Trade focus highlights budget rows and ghosts other trades in 3D',(dim+dim2)>0&&m3!=='bad',`${dim2||dim} dimmed rows · 3D ${m3}`);
        TR.set(null);await sleep(450);
        check('RC8.8 Trade','Clearing trade focus restores rows',document.querySelectorAll('#tERP .rc88Dim').length===0,'cleared');openDeckTab('tDash');}
      const PF=window.ARTEMIS_PLATFORM;
      if(PF){PF.set('procore');const code=PF.code(E.byId.A04,'L'),csv=PF.budgetCSV();PF.set('cmic');
        check('RC8.8 Platform','Procore cost-code mapping and budget import',code==='23-0410.L'&&csv[0].includes('Cost Type')&&csv.length>40,`${code} · ${csv.length-1} budget lines`);
        check('RC8.8 Platform','CMiC mapping unchanged',PF.code(E.byId.A04,'L')==='0410-DUCT-L',PF.code(E.byId.A04,'L'));}
      const PO=window.ARTEMIS_POP;
      if(PO){const bad=[];['source','bim','qto','cost','evm','field','labor','exec','floor:3','equip:RTU-1'].forEach(k=>{try{PO.open(k);const p=$('rc88Pop');if(!p||!p.classList.contains('on')||(p.textContent||'').length<80)bad.push(k);}catch(e){bad.push(k+' '+e.message);}});
        $('rc88Pop')?.classList.remove('on');
        check('RC8.8 Story','Every story-page window opens with live content',!bad.length,bad.join(', ')||'10 windows');}
      check('RC8.8 Story','Hero building parts are interactive (floors, roof, source, 7 stations)',document.querySelectorAll('.narFeedSpine [data-pop]').length>=18&&/LABOR/.test(document.querySelector('.narFeedSpine svg')?.textContent||''),document.querySelectorAll('.narFeedSpine [data-pop]').length+' hot spots');
      if(window.ARTEMIS_RUN&&LB){const prm0=ARTEMIS_RUN.toParam();LB.LAB.crews.A05=4;recalcAll(false);const prm=ARTEMIS_RUN.toParam();ARTEMIS_RUN.apply(ARTEMIS_RUN.decode(prm));const snapA=JSON.stringify(window.ARTEMIS_SELFTEST.snapshot());
        LB.LAB.crews.A05=2;recalcAll(false);ARTEMIS_RUN.apply(ARTEMIS_RUN.decode(prm));const a05=LB.LAB.crews.A05,snapB=JSON.stringify(window.ARTEMIS_SELFTEST.snapshot()),ok=snapB===snapA&&a05===4;
        ARTEMIS_RUN.apply(ARTEMIS_RUN.decode(prm0));
        check('RC8.8 Run link','Run link carries the labor plan',ok,ok?'crews A05 = 4 restored':`A05=${a05} · ${snapA} vs ${snapB}`);}

      /* ---------- RC8.9: Cost Heat Map */
      const HT=window.ARTEMIS_HEAT;
      if(HT){
        const cats=HT.catTotals(),ct=cats.reduce((a,c)=>a+c.est,0);
        check('RC8.9 Heat map','Category totals equal direct cost',Math.abs(ct-E.subtotal)<2,`${money(ct)} vs ${money(E.subtotal)}`);
        const tm=HT.squarify(cats.map(c=>({k:c.k,v:c.est})),0,0,400,300),areaOk=tm.every(r=>Math.abs(r.w*r.h/(400*300)-r.v/ct)<.002);
        check('RC8.9 Heat map','Treemap tile area ∝ category budget',areaOk&&tm.length===cats.length,tm.map(r=>`${r.k} ${(r.w*r.h/1200).toFixed(1)}%`).join(' · '));
        const mAll=HT.model(null),L=HT.mosaic(mAll,900,430,0,0),sumA=L.rects.reduce((a,r)=>a+r.w*r.h,0);
        const prop=L.rects.every(r=>Math.abs(r.w*r.h/sumA-r.est/L.tot)<.003);
        check('RC8.9 Heat map','2-way map: block area ∝ scope × cost-type budget',prop,`${L.rects.length} blocks · ${money(L.tot)}`);
        let catOk=true,notes=[];
        CAT_KEYS.forEach(k=>{const m=HT.model(k);const s=m.cols.reduce((a,c)=>a+c.items.reduce((x,i)=>x+i.est,0),0),want=E.rows.reduce((a,r)=>a+(r.cat[k]||0),0);
          if(Math.abs(s-want)>1)catOk=false;notes.push(`${k} ${money(s)}`);
          const Lk=HT.mosaic(m,900,430,0,0),sk=Lk.rects.reduce((a,r)=>a+r.w*r.h,0);if(!Lk.rects.every(r=>Math.abs(r.w*r.h/sk-r.est/Lk.tot)<.003))catOk=false;});
        check('RC8.9 Heat map','Category filter: zone blocks sum to the category budget, area ∝ $',catOk,notes.join(' · '));
        HT.state.split='local';const ml=HT.model('L');HT.state.split='zone';
        check('RC8.9 Heat map','Labor drill splits by union local',ml.cols.some(c=>c.items.some(i=>i.local==='L28'))&&Math.abs(ml.cols.reduce((a,c)=>a+c.est,0)-E.rows.reduce((a,r)=>a+r.cat.L,0))<1,'L28 · L638 · …');
        openDeckTab('tHeat');HT.render();HT.setCat('M');
        const cells=document.querySelectorAll('#htMosaicSvg [data-htkey]').length,tiles=document.querySelectorAll('#htTreeSvg [data-htcat]').length;
        check('RC8.9 Heat map','Tab renders treemap, filtered 2-way map and ranking',tiles>=4&&cells>0&&document.querySelectorAll('#htRank tbody tr').length>0&&/Material/.test($('htTitle')?.textContent||''),`${tiles} tiles · ${cells} Material blocks`);
        const first=document.querySelector('#htMosaicSvg [data-htkey]');first?.dispatchEvent(new MouseEvent('click',{bubbles:true}));
        check('RC8.9 Heat map','Clicking a block selects it and shows detail',!!HT.state.sel&&/Budget/.test($('htDetail')?.textContent||''),HT.state.sel||'none');
        HT.setCat(null);openDeckTab('tDash');
      }else add('RC8.9 Heat map','ARTEMIS_HEAT present','FAIL','missing');

      /* ---------- RC8.10: sound studio */
      const SD=window.ARTEMIS_SOUND;
      if(SD){
        check('RC8.10 Sound','Sound is off until the viewer turns it on',SD.state.on===false,'off by default');
        check('RC8.10 Sound','Five music variations and interaction effects',Object.keys(SD.variations).length===5&&SD.fx.length>=12,`${Object.keys(SD.variations).join(', ')} · ${SD.fx.length} effects`);
        check('RC8.10 Sound','Sound toggles in the app header and the story page',document.querySelectorAll('.sndToggle').length>=2&&!!$('sndPanel'),document.querySelectorAll('.sndToggle').length+' toggles');
        if(window.OfflineAudioContext||window.webkitOfflineAudioContext){
          const peaks=[];for(const k of Object.keys(SD.variations)){const b=await SD.render(k,8);const d=b.getChannelData(0);let p=0,sq=0;for(let i=0;i<d.length;i++){const a=Math.abs(d[i]);if(a>p)p=a;sq+=d[i]*d[i];}peaks.push({k,p,rms:Math.sqrt(sq/d.length)});}
          check('RC8.10 Sound','Every variation renders audible and unclipped',peaks.every(x=>x.p>.01&&x.p<.99),peaks.map(x=>`${x.k} pk ${x.p.toFixed(2)}`).join(' · '));
          const fx=[];for(const k of SD.fx){const b=await SD.renderSfx(k,{t:.5,dir:1});const d=b.getChannelData(0);let p=0;for(let i=0;i<d.length;i++)p=Math.max(p,Math.abs(d[i]));fx.push([k,p]);}
          check('RC8.10 Sound','Every sound effect renders',fx.every(x=>x[1]>.002&&x[1]<.99),fx.map(x=>`${x[0]} ${x[1].toFixed(2)}`).join(' · '));
          const a=await SD.render('still',4),b=await SD.render('still',4),da=a.getChannelData(0),db=b.getChannelData(0);let same=true;for(let i=0;i<da.length;i+=97)if(Math.abs(da[i]-db[i])>1e-6){same=false;break;}
          check('RC8.10 Sound','Music is seeded and reproducible',same,'two renders identical');
        }else add('RC8.10 Sound','Offline render','WARN','OfflineAudioContext not available here (headless)');
      }else add('RC8.10 Sound','ARTEMIS_SOUND present','FAIL','missing');

      /* ---------- RC8.11: System Lab */
      const LB2=window.ARTEMIS_LAB;
      if(LB2){
        check('RC8.11 Lab','Refrigerant saturation fit (45 °F ≈ 144 psia, 117 °F ≈ 411 psia)',Math.abs(LB2.psat(45)-144)<5&&Math.abs(LB2.psat(117)-411)<12&&Math.abs(LB2.tsat(LB2.psat(80))-80)<.01,`${LB2.psat(45).toFixed(1)} · ${LB2.psat(117).toFixed(1)} psia`);
        const cy=LB2.cycle({Te:45,Tc:117});
        check('RC8.11 Lab','Cycle COP plausible and COPh = COPc + 1',cy.COPc>2.8&&cy.COPc<4.5&&Math.abs(cy.COPh-cy.COPc-1)<1e-9&&cy.T2>cy.Tc&&cy.x4>0&&cy.x4<1,`COPc ${cy.COPc.toFixed(2)} · discharge ${cy.T2.toFixed(0)} °F · quality ${(cy.x4*100).toFixed(0)} %`);
        const el=LB2.electrical(15),others=el.RLA*(el.u.comps-1)+el.fanFLA+el.cfFLA*el.u.condFans+1;
        check('RC8.11 Lab','MCA and MOCP follow NEC 440.33 / 440.22',Math.abs(el.MCA-(1.25*el.RLA+others))<.01&&el.MOCP<=2.25*el.RLA+others&&el.MOCP>=el.MCA,`MCA ${el.MCA.toFixed(1)} A · MOCP ${el.MOCP} A`);
        check('RC8.11 Lab','Three-phase power identity kW = √3·V·I·PF',Math.abs(el.kW-Math.sqrt(3)*el.vAvg*el.I*el.pf/1000)<.01,`${el.kW.toFixed(1)} kW · ${el.I.toFixed(0)} A · PF ${el.pf.toFixed(2)}`);
        const s0=LB2.state.svc;LB2.state.svc='208';const bad=LB2.compat().find(r=>/Service voltage/.test(r.item));LB2.state.svc=s0;const good=LB2.compat().find(r=>/Service voltage/.test(r.item));
        check('RC8.11 Lab','Compatibility flags a 460 V unit on a 208 V service',bad.status==='fail'&&good.status==='pass',`208 → ${bad.status} · ${s0} → ${good.status}`);
        const cxs=LB2.cxStatus();
        check('RC8.11 Lab','Commissioning stages in order on the schedule',cxs.length===9&&cxs.every((r,i)=>i===0||r.due>=cxs[i-1].due),cxs.map(r=>r.id+'@D'+r.due).join(' '));
        const du=LB2.duty();
        check('RC8.11 Lab','Duty cycle: 24 hours, starts ≤ 6 per hour',du.rows.length===24&&du.maxStarts<=6.0001,`${du.kwh.toFixed(0)} kWh/unit · max ${du.maxStarts.toFixed(1)} starts/h`);
        LB2.open('flow');const empty=[];for(const k of ['flow','cycle','elec','compat','cx','duty','3d']){LB2.section(k);const sec=document.querySelector(`#labPage section[data-sec="${k}"]`);if(!sec||sec.innerHTML.length<200)empty.push(k);}
        check('RC8.11 Lab','Every System Lab section renders',!empty.length&&$('labPage').classList.contains('on'),empty.join(',')||'7 sections');
        if(typeof THREE!=='undefined'&&LB2.V3.ok){
          const V=LB2.V3,cs=V.byKey.casing[0];LB2.explodeNow(0);const y0=cs.grp.position.y;LB2.explodeNow(1);const y1=cs.grp.position.y;LB2.explodeNow(0);
          check('RC8.11 Lab','3D model: parts, explode and views',V.parts.length>=15&&y1>y0+5&&document.querySelectorAll('#vcCube [data-vc]').length===6,`${V.parts.length} part groups · casing lifts ${(y1-y0).toFixed(1)}`);
          LB2.goView('top',true);const ortho=V.proj==='ortho';LB2.goView('iso3',true);
          check('RC8.11 Lab','Plan view is orthographic; 3D view is perspective',ortho&&V.proj==='persp','top → ortho · 3D → persp');
        }else add('RC8.11 Lab','3D model','WARN','WebGL not available here');
        LB2.close();
        check('RC8.11 Lab','Lab closes back to the workbench',!$('labPage').classList.contains('on'),'closed');
      }else add('RC8.11 Lab','ARTEMIS_LAB present','FAIL','missing');

      /* ---------- palette & guards */
      window.ARTEMIS_PALETTE?.open?.();const pal=$('rc85Palette');
      check('UX','Command palette opens',!!pal,(window.ARTEMIS_PALETTE?.commands?.length||0)+' commands');pal?.remove();
      check('Guards','No guarded render failures',!(window.ARTEMIS_GUARD?.getFailures?.().length),(window.ARTEMIS_GUARD?.getFailures?.().length||0)+' failures');
      const bc=window.ARTEMIS_BOUNDARY?.check?.();
      check('Boundary','ARTEMIS_BOUNDARY.check() ok',bc&&bc.ok,bc?JSON.stringify(bc):'missing');
    }catch(err){
      add('Runner','Suite crashed','FAIL',err&&err.stack||err);
    }finally{
      try{
        Object.entries(saved).forEach(([k,v])=>setInput(k,v));
        if(window.RC83_applyScenario)window.RC83_applyScenario(savedMode);else recalcAll();
      }catch(e){}
    }
    const pass=rows.filter(r=>r.status==='PASS').length,warn=rows.filter(r=>r.status==='WARN').length,fail=rows.filter(r=>r.status==='FAIL').length;
    if(console.table)console.table(rows);
    console.info(`[ARTEMIS acceptance] ${pass} pass · ${warn} warn · ${fail} fail`);
    return {pass,warn,fail,rows};
  }
  window.ARTEMIS_ACCEPTANCE={run,BOUNDARY,COMPANY,GOLDEN_DEFAULT};
})();
