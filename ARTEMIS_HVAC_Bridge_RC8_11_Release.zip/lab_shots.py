import time,sys,json
from playwright.sync_api import sync_playwright
html=sys.argv[1];logs=[]
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
    pg=b.new_page(viewport={'width':1600,'height':1000})
    pg.on('console',lambda m: logs.append(f'{m.type}: {m.text[:300]}'))
    pg.on('pageerror',lambda e: logs.append(f'PAGEERROR: {str(e)[:400]}'))
    pg.goto('file://'+html); time.sleep(3)
    pg.evaluate("openNarrativePage(false)"); time.sleep(.8)
    print(json.dumps(pg.evaluate("""(()=>{const L=ARTEMIS_LAB,P=L.plant(15),E=L.electrical(15),c=L.cycle({Te:45,Tc:117});return {unit:L.unit(),psat45:L.psat(45),psat117:L.psat(117),cop:c.COPc,T2:c.T2,RE:c.RE,W:c.W,plant:{stages:P.stages,kw:P.kw,eer:P.eer,tons:P.tonsOut,cfm:P.cfm},elec:{RLA:E.RLA,MCA:E.MCA,MOCP:E.MOCP,I:E.I,kW:E.kW,pf:E.pf,vImb:E.vImb,wind:E.winding},compat:L.compat().map(r=>r.item+':'+r.status),cx:L.cxStatus().map(r=>r.id+':'+r.status)}})()"""),indent=0)[:2500])
    pg.evaluate("ARTEMIS_LAB.open('3d')"); time.sleep(2.5)
    pg.screenshot(path='shots/01_lab_3d.png')
    pg.evaluate("ARTEMIS_LAB.state.explode=1"); time.sleep(1.6); pg.screenshot(path='shots/02_lab_3d_exploded.png')
    pg.evaluate("ARTEMIS_LAB.goView('axo')"); time.sleep(1); pg.screenshot(path='shots/03_lab_axo_exploded.png')
    pg.evaluate("ARTEMIS_LAB.goView('front')"); time.sleep(1); pg.screenshot(path='shots/04_lab_front.png')
    pg.evaluate("ARTEMIS_LAB.goView('top')"); time.sleep(1); pg.screenshot(path='shots/05_lab_top.png')
    pg.evaluate("ARTEMIS_LAB.state.explode=0;ARTEMIS_LAB.goView('iso3');ARTEMIS_LAB.select('coil');ARTEMIS_LAB.state.xray=true"); time.sleep(1.6); pg.screenshot(path='shots/06_lab_xray_coil.png')
    for k in ['flow','cycle','elec','compat','cx','duty']:
        pg.evaluate(f"ARTEMIS_LAB.section('{k}')"); time.sleep(1.2); pg.screenshot(path=f'shots/07_lab_{k}.png')
    pg.evaluate("ARTEMIS_LAB.state.sys='chw';ARTEMIS_LAB.section('3d')"); time.sleep(1.5)
    pg.evaluate("ARTEMIS_LAB.section('flow')"); time.sleep(1); pg.screenshot(path='shots/08_lab_flow_chw.png')
    pg.evaluate("ARTEMIS_LAB.state.mode='heat';ARTEMIS_LAB.section('cycle')"); time.sleep(1); pg.screenshot(path='shots/09_lab_cycle_heat.png')
    b.close()
errs=[l for l in logs if l.startswith(('error','PAGEERROR'))or 'skipped' in l]
print('ERRORS',len(errs));[print(' ',e) for e in errs[:15]]
