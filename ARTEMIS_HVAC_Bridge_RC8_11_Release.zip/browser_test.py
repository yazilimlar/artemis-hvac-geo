import time, sys
from playwright.sync_api import sync_playwright
html=sys.argv[1]; tests=open('artemis_acceptance_tests.js',encoding='utf-8').read();logs=[]
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-gl=swiftshader','--enable-webgl','--ignore-gpu-blocklist'])
    pg=b.new_page(viewport={'width':1600,'height':1000})
    pg.on('console',lambda m: logs.append(f'{m.type}: {m.text[:220]}'));pg.on('pageerror',lambda e: logs.append(f'PAGEERROR: {str(e)[:300]}'))
    pg.goto('file://'+html); time.sleep(3.5)
    pg.evaluate("openNarrativePage(false)"); time.sleep(1)
    # real interaction: open from Model menu, orbit with mouse, wheel zoom, click ViewCube
    pg.click('#menuModel > button'); time.sleep(.3); pg.click('#btnSystemLab'); time.sleep(2)
    box=pg.query_selector('#lab3dView canvas').bounding_box(); cx,cy=box['x']+box['width']/2,box['y']+box['height']/2
    pg.mouse.move(cx,cy); pg.mouse.down(); pg.mouse.move(cx+220,cy-60,steps=12); pg.mouse.up(); time.sleep(.6)
    pg.mouse.wheel(0,-400); time.sleep(.6); pg.screenshot(path='shots/10_orbit_zoom.png')
    pg.click('#vcCube [data-vc="front"]'); time.sleep(1); pg.screenshot(path='shots/11_viewcube_front.png')
    pg.click('#lab3d [data-v3view="axo"]'); time.sleep(.8); pg.evaluate("ARTEMIS_LAB.state.explode=.7"); time.sleep(1.6); pg.screenshot(path='shots/12_axo_explode70.png')
    pg.evaluate("ARTEMIS_LAB.close()"); time.sleep(.5)
    res=pg.evaluate(tests+"\n;ARTEMIS_ACCEPTANCE.run()")
    print('ACCEPT',res['pass'],'pass',res['warn'],'warn',res['fail'],'fail')
    for r in res['rows']:
        if r['status']!='PASS': print('  ',r['status'],r['label'],'|',r['note'][:200])
    b.close()
errs=[l for l in logs if l.startswith(('error','PAGEERROR'))]
print('CONSOLE ERRORS',len(errs)); [print('  ',e) for e in errs[:12]]
