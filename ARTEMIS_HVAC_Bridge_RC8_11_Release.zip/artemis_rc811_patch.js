/* =====================================================================================
   ARTEMIS HVAC MECHANICAL INTELLIGENCE BRIDGE — RC8.11 PATCH (P49)
   George Oktem · New York · 2026 · Artemis Construction

   P49 System Lab — a full-screen page that explains how the HVAC system works and
       integrates, driven by the live model (hour, load, outdoor air, tonnage, units):
         · 3D exploded rooftop unit → supply duct → VAV terminal → diffuser, with
           Revit / CATIA-style orbit (drag orbit · right-drag pan · wheel zoom to cursor ·
           double-click to orbit about a part), ViewCube, axonometric / perspective and
           2D orthographic views (top, front, right, back, left), explode slider, x-ray,
           labels, turntable, isolate, live airflow and refrigerant particles
         · 2D flow schematic (air, refrigerant or chilled water, electrical, controls)
         · Refrigeration cycle on a pressure–enthalpy chart (cooling and heat-pump)
         · Electrical: one-line, three-phase phasors, live volts / amps / kW / PF,
           MCA / MOCP, winding and discharge temperatures
         · Compatibility checks (power, controls protocol, refrigerant, structure,
           duct pressure class, energy code), testing & commissioning standards with
           benchmarks and a seeded test simulator, and design-day duty cycles
   Values are representative engineering approximations for a public demonstration —
   not sealed design, not a product selection, not a substitute for manufacturer data,
   the current code editions, or contract reconciliation.
   ===================================================================================== */
(function(){
  'use strict';
  const PATCH='RC8.11';
  const applied=[];
  const warn=(tag,err)=>console.warn(`[${PATCH}] ${tag} skipped`,err);
  const mark=id=>applied.push(id);
  const $id=id=>document.getElementById(id);
  const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const css=t=>{const s=document.createElement('style');s.textContent=t;document.head.appendChild(s);};
  const on=(ev,fn)=>window.ARTEMIS?.on?.(ev,fn);
  const cl=(x,a,b)=>Math.max(a,Math.min(b,x));
  const f1=v=>fmt(v,1),f0=v=>fmt(v,0);
  const seeded=s=>{let x=s>>>0||1;return()=>{x^=x<<13;x>>>=0;x^=x>>17;x^=x<<5;x>>>=0;return x/4294967296;};};
  const H=()=>window.ARTEMIS_HVAC;
  const isJsdom=/jsdom/i.test(navigator.userAgent||'');
  const snd=(k,o)=>{try{window.ARTEMIS_SOUND?.play?.(k,o);}catch(e){}};

  /* ---------------------------------------------------------------- state */
  const LS={open:false,section:'3d',sys:'dx',mode:'cool',hour:15,winterOA:15,
    unitV:'460',svc:'460',proto:'bacnet-ip',bas:'bacnet',refr:'R-454B',leakDet:true,roofPsf:30,dunnage:true,ductClass:2,economizer:true,heat:'hp',
    explode:0,xray:false,labels:true,turntable:false,layers:{air:true,ref:true,water:true,elec:true,ctrl:true},cxRun:{},sel:null};

  /* ---------------------------------------------------------------- unit & load */
  const NOM=[20,25,30,40,50,60,70,75,90,105,120,130,150];
  function unit(){
    const n=Math.max(1,G.equipEA),tons=G.tonnage/n,nom=NOM.reduce((a,b)=>Math.abs(b-tons)<Math.abs(a-tons)?b:a,NOM[0]);
    const dd=H()?.designDay?.();const cfm=dd?dd.designCFM/n:nom*400;
    const tsp=H()?.HV?.tsp||3.5,eff=H()?.HV?.fanEff||.65;
    const bhp=cfm*tsp/(6356*eff);
    return {n,tons,nom,cfm,tsp,bhp,comps:nom>=40?4:2,condFans:Math.max(2,Math.round(nom/12)),weight:nom*140,curbSF:Math.max(80,nom*3.2)};
  }
  function op(hour){
    const h=hour??LS.hour,hv=H();
    const oa=LS.mode==='heat'?LS.winterOA:(hv?hv.oaDB(h):91.6);
    let lf=hv?hv.loadFrac(h):.9;
    if(LS.mode==='heat')lf=cl((65-oa)/(65-15),.15,1.1);
    const eco=LS.mode==='cool'&&LS.economizer&&oa<55;
    return {h,oa,lf,eco};
  }

  /* ---------------------------------------------------------------- refrigerant (R-454B / R-410A class, representative fit) */
  const psat=T=>Math.exp(13.387-4249/(T+459.67));                        // psia; 45 °F → 144, 117 °F → 411
  const tsat=P=>4249/(13.387-Math.log(P))-459.67;
  const hf=T=>27+.361*(T-45)+.0066*Math.max(0,T-110)**2;                  // Btu/lb, sat. liquid
  const hg=T=>122.5+.035*(T-45)-.0006*(T-45)**2-.01344*Math.max(0,T-110)**2; // Btu/lb, sat. vapor
  const TCRIT=160;
  function cycle(o){
    const {Te,Tc,sh=10,sc=10,eta=.72}=o;
    const P1=psat(Te),P2=psat(Tc);
    const h1=hg(Te)+.22*sh,T1=Te+sh;
    const h2s=h1+.21*(Tc-Te)*(1+.0015*(Tc-Te));
    const h2=h1+(h2s-h1)/eta,T2=Tc+(h2-hg(Tc))/.30;
    const h3=hf(Tc)-.38*sc,T3=Tc-sc,h4=h3;
    const x4=cl((h4-hf(Te))/(hg(Te)-hf(Te)),0,1);
    const RE=h1-h4,W=h2-h1,COPc=RE/W,COPh=(h2-h3)/W;
    return {Te,Tc,sh,sc,eta,P1,P2,h1,h2,h2s,h3,h4,T1,T2,T3,x4,RE,W,COPc,COPh,ratio:P2/P1,mdotPerTon:200/RE};
  }
  function plant(hour){
    const u=unit(),o=op(hour),hv=H();
    const sat=hv?.HV?.supplyT??55;
    let Te,Tc,cap,mode=LS.mode;
    /* heat pumps lose capacity as the outdoor coil gets colder (about 60 % of nominal at 15 °F) */
    const capFrac=mode==='heat'?cl(.62+.0095*(o.oa-17),.4,1.05):1;
    if(mode==='heat'){Te=o.oa-15;Tc=95+20;}
    else{Te=sat-10+4*(1-cl(o.lf,0,1));Tc=Math.max(70,o.oa+20);}
    const cyc=cycle({Te,Tc});
    const stagesMax=u.comps;
    const need=mode==='heat'?o.lf*u.nom:(o.eco?0:cl(o.lf,0,1.1)*u.tons);
    const stages=o.eco?0:Math.min(stagesMax,Math.ceil(need/(u.nom/stagesMax)-1e-9));
    const frac=stages?need/(stages*u.nom/stagesMax):0;            // duty within the top stage
    const tonsOut=Math.min(need,stages*u.nom/stagesMax*capFrac),backupTons=Math.max(0,need-tonsOut);
    const motorEff=.92;
    const kwComp=tonsOut>0?(mode==='heat'?tonsOut*12000/(cyc.COPh*3412)/motorEff:tonsOut*12000/(cyc.COPc*3412)/motorEff):0;
    const flow=cl(o.lf,.3,1);
    const kwFan=u.bhp*.746/.93*Math.pow(flow,2.5)/.97;               // VFD 97 %
    const kwCond=(mode==='cool'&&stages)?u.condFans*.85*cl(.4+.6*(o.oa-55)/40,.3,1):(mode==='heat'&&stages?u.condFans*.85:0);
    const kw=kwComp+kwFan+kwCond+.4;
    const eer=tonsOut>0?tonsOut*12000/(kw*1000):0;
    return {u,o,cyc,stages,stagesMax,frac,need,tonsOut,capFrac,backupTons,kwComp,kwFan,kwCond,kw,eer,flow,cfm:u.cfm*flow,mode,sat,
      kwPerTon:tonsOut>0?kw/tonsOut:0,cop:mode==='heat'?cyc.COPh:cyc.COPc};
  }

  /* ---------------------------------------------------------------- electrical (NEC 430.250 FLA, 440.33 MCA, 440.22 MOCP) */
  const FLA={460:{1:2.1,1.5:3.0,2:3.4,3:4.8,5:7.6,7.5:11,10:14,15:21,20:27,25:34,30:40,40:52,50:65,60:77,75:96,100:124},
             208:{1:4.6,1.5:6.6,2:7.5,3:10.6,5:16.7,7.5:24.2,10:30.8,15:46.2,20:59.4,25:74.8,30:88,40:114,50:143,60:169,75:211,100:273}};
  const HP=[1,1.5,2,3,5,7.5,10,15,20,25,30,40,50,60,75,100];
  const OCP=[15,20,25,30,35,40,45,50,60,70,80,90,100,110,125,150,175,200,225,250,300,350,400,450,500,600,700,800];
  function electrical(hour){
    const P=plant(hour),u=P.u,V=+LS.unitV,tbl=FLA[V===460?460:208];
    const fullCyc=cycle({Te:45,Tc:117});
    const kwCompFull=u.nom*12000/(fullCyc.COPc*3412)/.92/u.comps;
    const pfC=.88,pfF=.85;
    const RLA=kwCompFull*1000/(Math.sqrt(3)*V*pfC),LRA=RLA*6.5;
    const fanHP=HP.find(h=>h>=u.bhp*1.1)||100,fanFLA=tbl[fanHP];
    const cfHP=1,cfFLA=tbl[cfHP];
    const others=RLA*(u.comps-1)+fanFLA+cfFLA*u.condFans+(V===460?1:2);
    const MCA=1.25*RLA+others;
    const mocpMax=2.25*RLA+others;
    const MOCP=[...OCP].reverse().find(s=>s<=mocpMax)||15;
    /* live operation */
    const iComp=P.stages?(P.stages-1+P.frac)*RLA*cl(.78+.004*(P.cyc.Tc-95),.7,1.05):0;
    const iFan=fanFLA*(.25+.75*Math.pow(P.flow,2.6));
    const iCond=P.kwCond>0?cfFLA*u.condFans*cl(P.kwCond/(u.condFans*.85),0,1):0;
    const I=iComp+iFan+iCond+(V===460?.6:1.3);
    const t=(performance.now()/1000)%60,r=seeded(17+Math.floor(LS.hour))();
    const vAvg=V*(1-.012+.008*Math.sin(LS.hour/3));
    const vPh=[vAvg*(1+.006),vAvg*(1-.004),vAvg*(1-.002)];
    const vMax=Math.max(...vPh.map(v=>Math.abs(v-vAvg)));const vImb=vMax/vAvg*100;
    const iImb=vImb*7;                                          // current imbalance runs ~6–10× voltage imbalance
    const iPh=[I*(1+iImb/100),I*(1-iImb/200),I*(1-iImb/200)];
    const pf=I>0?(iComp*pfC+iFan*.96+iCond*pfF)/I:0;               // VFD fan near unity displacement PF
    const kW=Math.sqrt(3)*vAvg*I*pf/1000;
    const ambC=(P.o.oa-32)/1.8;
    const winding=ambC+40+65*Math.pow(cl(iComp/Math.max(1,P.stages*RLA),0,1.2),2)*(P.stages?1:0);
    return {P,u,V,RLA,LRA,fanHP,fanFLA,cfFLA,MCA,MOCP,mocpMax,iComp,iFan,iCond,I,vAvg,vPh,vImb,iImb,iPh,pf,kW,ambC,winding,discharge:P.cyc.T2,
      suctionPsig:P.cyc.P1-14.7,headPsig:P.cyc.P2-14.7};
  }

  /* ---------------------------------------------------------------- duty cycles over 24 h */
  function duty(){
    const rows=[];let starts=0;
    for(let h=0;h<24;h++){
      const P=plant(h);
      /* the top stage cycles when demand sits between stages: starts/h ≈ 4·f·(1−f)·6 (6 = max anti-short-cycle rate) */
      const f=P.frac,cyc=P.stages?Math.round(24*f*(1-f)*10)/10:0;
      starts+=cyc+(h>0&&P.stages!==rows[h-1].stages?Math.abs(P.stages-rows[h-1].stages):0);
      rows.push({backup:P.backupTons,h,oa:P.o.oa,lf:P.o.lf,stages:P.stages,frac:f,startsPerHr:cyc,kw:P.kw,eco:P.o.eco,cop:P.cop,tons:P.tonsOut,defrost:LS.mode==='heat'&&P.o.oa<40&&P.o.oa>17?1:0});
    }
    return {rows,starts,kwh:rows.reduce((s,r)=>s+r.kw,0),maxStarts:Math.max(...rows.map(r=>r.startsPerHr))};
  }

  /* ---------------------------------------------------------------- compatibility */
  function compat(){
    const E1=electrical(),u=E1.u,out=[];
    const row=(group,item,status,detail,basis)=>out.push({group,item,status,detail,basis});
    const svcV={'208':208,'460':460,'480':480}[LS.svc],uv=+LS.unitV;
    const lo=uv*.9,hi=uv*1.1;
    row('Power','Service voltage vs unit nameplate',svcV>=lo&&svcV<=hi?'pass':'fail',
      `Unit ${uv===460?'460-3-60':'208/230-3-60'} on a ${LS.svc==='208'?'208Y/120 V network':LS.svc==='460'?'460Y/265 V spot network':'480Y/277 V'} service · utilization range ${f0(lo)}–${f0(hi)} V`,'NEMA MG 1 / AHRI 110 ±10 %');
    row('Power','Feeder and overcurrent device',E1.MOCP<=600?'pass':'watch',`MCA ${f1(E1.MCA)} A → conductor sized ≥ MCA · MOCP ${E1.MOCP} A (max ${f0(E1.mocpMax)} A)`,'NEC 440.33 / 440.22');
    row('Power','Voltage imbalance at full load',E1.vImb<=1?'pass':E1.vImb<=2?'watch':'fail',`${f1(E1.vImb)} % voltage · ≈ ${f1(E1.iImb)} % current`,'NEMA MG 1: derate motors above 1 %');
    const protoOK={bacnet:['bacnet-ip','bacnet-mstp'],niagara:['bacnet-ip','bacnet-mstp','modbus','lon'],lon:['lon']}[LS.bas]||[];
    row('Controls','Unit controller ↔ building automation',protoOK.includes(LS.proto)?'pass':'watch',
      protoOK.includes(LS.proto)?`${LS.proto.toUpperCase()} native to the ${LS.bas==='niagara'?'Niagara':LS.bas==='lon'?'LonWorks':'BACnet'} front end`:`${LS.proto.toUpperCase()} needs a protocol gateway to the ${LS.bas} front end`,'ASHRAE 135 (BACnet) · BTL listing');
    row('Controls','Sequences of operation','pass','VAV, economizer, demand-controlled ventilation and fault detection per a published sequence library','ASHRAE Guideline 36');
    const a2l=LS.refr!=='R-410A';
    row('Refrigerant',`${LS.refr} safety class`,a2l?(LS.leakDet?'pass':'fail'):'watch',
      a2l?`A2L (mildly flammable): ${LS.leakDet?'factory leak detection and mitigation fitted':'leak detection / mitigation missing'}`:'A1, but new-equipment phase-down under the AIM Act Technology Transitions rule — verify the install date window',
      a2l?'ASHRAE 15-2022 · ASHRAE 34 · UL 60335-2-40':'EPA Technology Transitions rule');
    const psf=u.weight/u.curbSF;
    row('Structure','Roof load at the curb',psf<=LS.roofPsf?'pass':LS.dunnage?'watch':'fail',`${f0(u.weight)} lb operating over ${f0(u.curbSF)} SF = ${f0(psf)} psf vs ${LS.roofPsf} psf roof capacity${psf>LS.roofPsf?(LS.dunnage?' · steel dunnage spreads the load to columns':' · needs dunnage or reinforcement'):''}`,'NYC Building Code Ch. 16 · ASCE 7 wind / seismic');
    const tsp=u.tsp,need=tsp*.8;
    row('Ductwork','Duct pressure class vs fan static',LS.ductClass>=need?'pass':LS.ductClass>=need*.75?'watch':'fail',`Class ${LS.ductClass} in. w.g. vs about ${f1(need)} in. at the supply main (fan TSP ${f1(tsp)} in.)`,'SMACNA HVAC Duct Construction Standards');
    row('Energy code','Air economizer',LS.economizer?'pass':'fail',`Climate zone 4A · ${f0(u.nom*12)} kBtu/h unit ${LS.economizer?'has':'lacks'} an integrated economizer`,'NYC Energy Conservation Code / ASHRAE 90.1');
    row('Energy code','Minimum efficiency (≥ 760 kBtu/h class)',E1.P.eer>=9.7||!E1.P.tonsOut?'pass':'watch',`Modeled EER at this hour ${f1(E1.P.eer)} · code minimum about EER 9.7 / IEER 11.2 at AHRI conditions`,'ASHRAE 90.1 Table 6.8.1 — verify the adopted edition');
    row('Emissions','Heating source',LS.heat==='hp'?'pass':'watch',LS.heat==='hp'?'Heat pump heating — all-electric':'Gas heat adds on-site emissions against the building limit','NYC Local Law 97');
    return out;
  }

  /* ---------------------------------------------------------------- testing & commissioning */
  const CX=[
    {id:'F',stage:'Factory & submittal',test:'Certified rating and listing',std:'AHRI 340/360 (packaged) · AHRI 550/590 (chillers) · UL 1995 / UL 60335-2-40',bench:'Certified EER / IEER ≥ code minimum; listing label on unit',act:'A07',meas:r=>`EER 10.2 · IEER 12.4 (certified)`,ok:r=>true},
    {id:'D',stage:'Installation',test:'Duct leakage test (zone 1 · repeats per zone)',std:'SMACNA HVAC Air Duct Leakage Test Manual · NYCECC duct testing (> 3 in. w.g.)',bench:'Leakage class ≤ 4 cfm/100 sf at 1 in. w.g. at test pressure',act:'A04',meas:r=>{const v=2.2+r()*2.6;return {v,txt:`CL ${f1(v)}`};},ok:m=>m.v<=4},
    {id:'R',stage:'Refrigeration',test:'Pressure, evacuation and decay',std:'Manufacturer IOM · ASHRAE 15 · EPA Section 608',bench:'N₂ hold 24 h no drop · evacuate ≤ 500 microns · decay ≤ 1,000 microns in 10 min',act:'A06',meas:r=>{const v=380+r()*240;return {v,txt:`${f0(v)} microns, decay to ${f0(v+300+r()*500)}`};},ok:m=>m.v<=500},
    {id:'E',stage:'Electrical',test:'Insulation resistance, rotation, imbalance',std:'NETA ATS · IEEE 43 · NEMA MG 1',bench:'IR ≥ 100 MΩ at 1,000 VDC (min. 5 MΩ, IEEE 43) · voltage imbalance ≤ 1 %',act:'A11',meas:r=>{const v=600+r()*1800;return {v,txt:`${f0(v)} MΩ · imbalance ${f1(electrical().vImb)} %`};},ok:m=>m.v>=100&&electrical().vImb<=2},
    {id:'S',stage:'Start-up',test:'Refrigerant and electrical start-up',std:'Manufacturer start-up report',bench:'Superheat 8–12 °F · subcooling 8–14 °F · compressor amps ≤ RLA · discharge < 225 °F',act:'A14',meas:r=>{const sh=8.5+r()*4.5,sc=9+r()*5;return {sh,sc,txt:`SH ${f1(sh)} °F · SC ${f1(sc)} °F · ${f0(electrical().discharge)} °F discharge`};},ok:m=>m.sh>=8&&m.sh<=12&&m.sc>=8&&m.sc<=14&&electrical().discharge<225},
    {id:'T',stage:'Test & balance',test:'Air and water balancing',std:'AABC · NEBB · TABB procedures · ASHRAE 111',bench:'Terminals within ±10 % of design · total supply −5 / +10 % · outdoor air ≥ design',act:'A13',meas:()=>{const sp=H()?.spaces?.()||[];const t=sp.filter(x=>x.tested);const p=t.filter(x=>x.tab==='Pass').length;return {v:t.length?p/t.length:0,n:t.length,txt:t.length?`${p}/${t.length} terminals in tolerance`:'not yet tested'};},ok:m=>m.n>0&&m.v>=.9},
    {id:'C',stage:'Controls',test:'Point-to-point and sequences',std:'ASHRAE Guideline 36 · BACnet BTL',bench:'100 % points verified · sequences pass FPT · 7–14 day trends',act:'A12',meas:r=>{const v=96+r()*4.4;return {v,txt:`${f1(Math.min(100,v))} % points verified`};},ok:m=>m.v>=100},
    {id:'P',stage:'Functional performance',test:'Integrated system tests',std:'ASHRAE Standard 202 · ASHRAE Guideline 0 · NYCECC C408',bench:'All FPT steps pass; deficiencies closed; seasonal tests scheduled',act:'A14',meas:r=>{const v=r();return {v,txt:v>.2?'all steps pass':'2 deficiencies open'};},ok:m=>m.v>.2},
    {id:'X',stage:'Close-out',test:'Commissioning report & owner training',std:'NYCECC C408 · NYC DOB energy code progress inspections · Local Law 97 reporting',bench:'Final Cx report, O&M manuals, systems manual, training logged',act:'A15',meas:()=>({txt:'report issued'}),ok:()=>true}
  ];
  function cxStatus(){
    const day=SIM.day,order=['F','D','C','R','E','S','T','P','X'];
    return CX.map((c,i)=>{
      const w=actWindow(c.act),cx=actWindow('A14'),t=actWindow('A13'),d4=actWindow('A04');
      const due={F:Math.max(1,actWindow('A07').s-20),D:Math.round(d4.s+.3*(d4.f-d4.s)),C:actWindow('A12').s,R:Math.max(1,cx.s-6),E:Math.max(1,cx.s-3),S:cx.s,T:t.s+5,P:Math.max(cx.s+5,cx.f-3),X:actWindow('A15').f}[c.id]??w.s;
      const forced=LS.cxRun[c.id];const run=forced||day>=due;
      let m=null,pass=null;
      if(run){const r=seeded(4049+i*31+(forced?7:0));m=c.meas(r);if(typeof m==='string')m={txt:m};pass=!!c.ok(m);}
      return {...c,due,run,m,pass,status:!run?(day>=due-10?'Due':'Scheduled'):pass?'Pass':'Fail / retest'};
    }).sort((a,b)=>(a.due-b.due)||(order.indexOf(a.id)-order.indexOf(b.id)));
  }

  /* ================================================================ page shell */
  css(`
    #labPage{position:fixed;inset:0;z-index:8600;display:none;flex-direction:column;background:var(--bg,#eef2f7);color:var(--text,#13263a)}
    #labPage.on{display:flex}
    .labTop{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:8px 14px;border-bottom:1px solid var(--line);background:var(--panel)}
    .labTop h2{margin:0;font-size:16px;letter-spacing:-.01em}.labTop h2 small{display:block;font:600 9.5px var(--mono);letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}
    .labTop .sp{flex:1}
    .labTop label{font:800 9.5px var(--mono);letter-spacing:.08em;text-transform:uppercase;color:var(--muted);display:flex;gap:6px;align-items:center}
    .labSeg{display:inline-flex;border:1px solid var(--line);border-radius:9px;overflow:hidden}
    .labSeg button{all:unset;cursor:pointer;padding:5px 10px;font:700 11px var(--mono);color:var(--muted)}
    .labSeg button.on{background:var(--blue);color:#fff}
    .labChip{font:700 11px var(--mono);padding:4px 9px;border-radius:999px;background:var(--panel2);border:1px solid var(--line)}
    .labBody{flex:1;display:grid;grid-template-columns:186px minmax(0,1fr);min-height:0}
    .labNav{border-right:1px solid var(--line);background:var(--panel);padding:10px 8px;display:flex;flex-direction:column;gap:3px;overflow:auto}
    .labNav button{all:unset;cursor:pointer;padding:8px 10px;border-radius:9px;font-size:12.5px;font-weight:600;color:var(--text)}
    .labNav button small{display:block;font-weight:500;font-size:10px;color:var(--muted)}
    .labNav button.on{background:color-mix(in srgb,var(--blue) 14%,transparent);box-shadow:inset 3px 0 var(--blue)}
    .labNav button:focus-visible{outline:2px solid var(--blue)}
    .labMain{min-width:0;min-height:0;overflow:auto;padding:12px 14px}
    .labSec{display:none}.labSec.on{display:block}
    .labGrid{display:grid;grid-template-columns:minmax(0,1.5fr) minmax(300px,1fr);gap:12px;align-items:start}
    @media(max-width:1200px){.labGrid{grid-template-columns:1fr}}
    .labCard{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:10px 12px;box-shadow:var(--shadow);min-width:0;margin-bottom:12px}
    .labCard h4{margin:0 0 8px;font:800 10.5px var(--mono);letter-spacing:.1em;text-transform:uppercase;color:var(--blue);display:flex;gap:8px;justify-content:space-between;align-items:center;flex-wrap:wrap}
    .labCard h4 small{font-weight:600;letter-spacing:.02em;text-transform:none;color:var(--muted)}
    .labCard p{font-size:12px;line-height:1.5;color:var(--muted);margin:0 0 6px}
    .labBp{background:#0b1622;border-radius:12px;color:#d8ebff}
    .labBp svg{display:block;width:100%;height:auto}
    .labBp text{font-family:var(--mono)}
    .labKv{display:grid;grid-template-columns:repeat(auto-fit,minmax(118px,1fr));gap:6px;margin-bottom:8px}
    .labKv div{border:1px solid var(--line);border-radius:9px;padding:5px 8px;background:var(--panel2)}
    .labKv span{display:block;font:800 8.5px var(--mono);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}
    .labKv b{font:800 14px var(--mono)}.labKv em{display:block;font-style:normal;font-size:10px;color:var(--muted)}
    .labPill{display:inline-block;min-width:46px;text-align:center;padding:1px 7px;border-radius:999px;font:800 9px var(--mono);color:#fff}
    .labPill.pass{background:#178655}.labPill.watch{background:#b45309}.labPill.fail{background:#b42318}.labPill.idle{background:#64748b}
    .labCtl{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:8px}
    .labCtl label{font:800 9.5px var(--mono);letter-spacing:.06em;text-transform:uppercase;color:var(--muted);display:flex;gap:5px;align-items:center}
    .labLayers{display:flex;gap:6px;flex-wrap:wrap}
    .labLayers button{all:unset;cursor:pointer;font:700 10.5px var(--mono);padding:3px 9px;border-radius:999px;border:1px solid var(--line);display:inline-flex;gap:6px;align-items:center}
    .labLayers button i{width:12px;height:3px;border-radius:2px;background:var(--c)}.labLayers button.off{opacity:.4}
    @media (prefers-reduced-motion:reduce){#labPage svg *{animation:none!important}}
  `);
  const SECS=[['3d','3D system','exploded · orbit · views'],['flow','Flow schematic','air · refrigerant · power · controls'],['cycle','Refrigeration cycle','pressure–enthalpy'],
    ['elec','Electrical','volts · amps · kW · temps'],['compat','Compatibility','requirements & checks'],['cx','Testing & commissioning','standards & benchmarks'],['duty','Duty & heat cycles','design day · staging']];
  function shell(){
    if($id('labPage'))return;
    const p=document.createElement('div');p.id='labPage';p.setAttribute('role','dialog');p.setAttribute('aria-label','System Lab');
    p.innerHTML=`
      <div class="labTop">
        <h2>System Lab<small>How the system works and fits · Artemis Construction</small></h2>
        <div class="labSeg" id="labSys"><button data-v="dx">DX rooftop unit</button><button data-v="chw">Chilled-water AHU</button></div>
        <div class="labSeg" id="labMode"><button data-v="cool">Cooling</button><button data-v="heat">Heat pump</button></div>
        <label>Hour<input type="range" id="labHour" min="0" max="23" step="1" style="width:140px"></label>
        <label id="labWinter" style="display:none">Outdoor °F<input type="number" id="labOA" min="-10" max="60" step="1" style="width:56px"></label>
        <button class="hbtn" id="labPlay" type="button">▶ Day</button>
        <span class="labChip" id="labStat"></span>
        <span class="sp"></span>
        <button class="hbtn" id="labClose" type="button">← Back to workbench</button>
      </div>
      <div class="labBody">
        <nav class="labNav" aria-label="System Lab sections">${SECS.map(([k,t,s])=>`<button type="button" data-sec="${k}">${t}<small>${s}</small></button>`).join('')}</nav>
        <div class="labMain" id="labMain">
          <section class="labSec" data-sec="3d" id="lab3d"></section>
          <section class="labSec" data-sec="flow" id="labFlow"></section>
          <section class="labSec" data-sec="cycle" id="labCycle"></section>
          <section class="labSec" data-sec="elec" id="labElec"></section>
          <section class="labSec" data-sec="compat" id="labCompat"></section>
          <section class="labSec" data-sec="cx" id="labCx"></section>
          <section class="labSec" data-sec="duty" id="labDuty"></section>
        </div>
      </div>`;
    document.body.appendChild(p);
    p.addEventListener('click',e=>{
      const s=e.target.closest('[data-sec]');if(s&&s.tagName==='BUTTON'){setSection(s.dataset.sec);return;}
      const sy=e.target.closest('#labSys [data-v]');if(sy){LS.sys=sy.dataset.v;rebuild3D=true;render();return;}
      const md=e.target.closest('#labMode [data-v]');if(md){LS.mode=md.dataset.v;render();return;}
      if(e.target.id==='labClose')close();
      if(e.target.id==='labPlay')togglePlay();
    });
    p.addEventListener('input',e=>{if(e.target.id==='labHour'){LS.hour=+e.target.value;if(H())H().HV.hour=LS.hour;render(true);}if(e.target.id==='labOA'){LS.winterOA=+e.target.value;render(true);}});
    document.addEventListener('keydown',e=>{if(LS.open&&e.key==='Escape'&&!document.querySelector('#sndPanel.open')){close();}});
  }
  let playT=null;
  function togglePlay(){const b=$id('labPlay');if(playT){clearInterval(playT);playT=null;b.textContent='▶ Day';return;}
    b.textContent='❚❚ Pause';playT=setInterval(()=>{LS.hour=(LS.hour+1)%24;if(H())H().HV.hour=LS.hour;$id('labHour').value=LS.hour;render(true);},900);}
  function setSection(k){LS.section=k;document.querySelectorAll('#labPage [data-sec]').forEach(n=>n.classList.toggle('on',n.dataset.sec===k));render();if(k==='3d')V3.resize();}
  function top(){
    $id('labHour').value=LS.hour;$id('labOA').value=LS.winterOA;$id('labWinter').style.display=LS.mode==='heat'?'':'none';
    document.querySelectorAll('#labSys [data-v]').forEach(b=>b.classList.toggle('on',b.dataset.v===LS.sys));
    document.querySelectorAll('#labMode [data-v]').forEach(b=>b.classList.toggle('on',b.dataset.v===LS.mode));
    const P=plant();
    $id('labStat').textContent=`${String(LS.hour).padStart(2,'0')}:00 · OA ${f1(P.o.oa)} °F · load ${pct(Math.min(1.1,P.o.lf),0)} · ${P.o.eco?'economizer':P.stages+'/'+P.stagesMax+' stages'} · ${f1(P.kw)} kW/unit`;
  }
  let rebuild3D=true;
  function render(light){
    if(!LS.open)return;
    try{top();}catch(e){warn('lab top',e);}
    const k=LS.section;
    try{
      if(k==='3d')render3D(light);
      if(k==='flow')renderFlow();
      if(k==='cycle')renderCycle();
      if(k==='elec')renderElec();
      if(k==='compat')renderCompat();
      if(k==='cx')renderCx();
      if(k==='duty')renderDuty();
    }catch(err){warn('lab '+k,err);}
  }
  const kv=(t,v,s)=>`<div><span>${t}</span><b>${v}</b>${s?`<em>${s}</em>`:''}</div>`;
  const pill=s=>`<span class="labPill ${s}">${s==='pass'?'PASS':s==='watch'?'WATCH':s==='fail'?'FAIL':esc(s)}</span>`;

  /* ================================================================ flow schematic */
  const LAYC={air:'#7cc0f5',ref:'#f472b6',water:'#34d399',elec:'#f59e0b',ctrl:'#c4b5fd'};
  function flowStates(){
    const hv=H(),P=plant();
    if(LS.mode==='heat'){const oa=LS.winterOA,ra=70,f=.2,ma=ra+(oa-ra)*f;return {oa:{db:oa},ra:{db:ra},ma:{db:ma},sa:{db:95},room:{db:70},P};}
    const st=hv?hv.states(LS.hour):null;return {...(st||{oa:{db:P.o.oa},ra:{db:76},ma:{db:79},sa:{db:55},room:{db:75}}),P};
  }
  function renderFlow(){
    const host=$id('labFlow');const S=flowStates(),P=S.P,E1=electrical(),L=LS.layers,chw=LS.sys==='chw';
    const sp=v=>Math.max(.25,2.4-1.8*v);                                   // animation period from intensity
    const dash=(d,c,on,period,w=3,da='6 9')=>on?`<path d="${d}" fill="none" stroke="${c}" stroke-width="${w}" stroke-dasharray="${da}" stroke-linecap="round"><animate attributeName="stroke-dashoffset" from="30" to="0" dur="${period.toFixed(2)}s" repeatCount="indefinite"/></path>`:'';
    const box=(x,y,w,h,t,sub,c='#1c3550')=>`<g><rect x="${x}" y="${y}" width="${w}" height="${h}" rx="7" fill="${c}" stroke="#4d6f92"/><text x="${x+w/2}" y="${y+h/2-(sub?3:-4)}" font-size="11" fill="#e8eef4" text-anchor="middle" font-weight="700">${t}</text>${sub?`<text x="${x+w/2}" y="${y+h/2+11}" font-size="9.5" fill="#9fc2e4" text-anchor="middle">${sub}</text>`:''}</g>`;
    const tag=(x,y,t,c='#e0b65a')=>`<text x="${x}" y="${y}" font-size="10" fill="${c}" font-weight="700">${t}</text>`;
    const af=P.flow,ref=P.stages/P.stagesMax;
    let s=`<svg viewBox="0 0 1120 560" role="img" aria-label="Animated system flow schematic">`;
    s+=`<rect x="0" y="0" width="1120" height="560" fill="#0b1622"/>`;
    /* unit casing */
    s+=`<rect x="30" y="60" width="640" height="210" rx="12" fill="none" stroke="#385d80" stroke-dasharray="4 4"/><text x="40" y="54" font-size="11" fill="#90a7c2">${chw?'AIR-HANDLING UNIT · AHU-1':'ROOFTOP UNIT · RTU-1 · '+P.u.nom+' ton · '+P.u.comps+' scroll compressors'}</text>`;
    s+=box(40,90,70,70,'OA','louver + damper');s+=box(40,180,70,70,'RELIEF','damper');
    s+=box(130,120,80,90,'MIX','box');s+=box(225,120,70,90,'FILTER','MERV 13');s+=box(310,120,90,90,chw?'CHW COIL':'DX COIL',chw?'2-way valve':'evaporator');
    s+=box(415,120,90,90,'SUPPLY FAN','VFD '+pct(P.flow,0));s+=box(520,120,70,90,LS.mode==='heat'?'HP HEAT':'HEAT','section');
    if(!chw){s+=box(310,280,100,46,'COMPRESSORS',`${P.stages}/${P.stagesMax} on`,'#3b1f35');s+=box(440,280,110,46,'CONDENSER','coil + '+P.u.condFans+' fans','#3b1f35');s+=box(330,350,90,34,'EEV / TXV','','#3b1f35');}
    else{s+=box(250,300,150,60,'AIR-COOLED CHILLER','evap · cond · comp','#173a2c');s+=box(440,310,80,40,'CHW PUMP','VFD','#173a2c');}
    /* air path */
    s+=dash('M75 90 V70 H170 V120',LAYC.air,L.air,sp(af));
    s+=dash('M110 165 H130 M210 165 H225 M295 165 H310 M400 165 H415 M505 165 H520 M590 165 H700 V140 H760',LAYC.air,L.air,sp(af),4);
    s+=box(760,110,90,60,'VAV BOX','damper + reheat');
    s+=dash('M850 140 H900 V230',LAYC.air,L.air,sp(af));
    s+=`<rect x="860" y="230" width="230" height="140" rx="8" fill="rgba(84,168,237,.08)" stroke="#385d80"/><text x="975" y="300" font-size="12" fill="#e8eef4" text-anchor="middle" font-weight="700">ZONE · L3-Z1</text><text x="975" y="316" font-size="10" fill="#9fc2e4" text-anchor="middle">diffusers · return grille · sensor</text>`;
    s+=box(880,235,60,22,'DIFFUSER','');
    s+=dash('M1060 370 V430 H700 V215 H110',LAYC.air,L.air,sp(af*.85),3,'3 10');
    s+=tag(690,445,'RETURN AIR · ceiling plenum',LAYC.air);
    /* refrigerant / water loops */
    if(!chw){
      s+=dash('M410 303 H440',LAYC.ref,L.ref&&P.stages>0,sp(ref),3);
      s+=dash('M550 303 H600 V367 H420',LAYC.ref,L.ref&&P.stages>0,sp(ref),3);
      s+=dash('M330 367 H280 V200 H310',LAYC.ref,L.ref&&P.stages>0,sp(ref),2.5,'3 7');
      s+=dash('M400 200 H420 V250 H360 V280',LAYC.ref,L.ref&&P.stages>0,sp(ref),3);
      s+=tag(560,296,`head ${f0(E1.headPsig)} psig`,LAYC.ref);s+=tag(214,250,`suction ${f0(E1.suctionPsig)} psig`,LAYC.ref);
    }else{
      const gpm=P.tonsOut*24/10;
      s+=dash('M325 300 V230 H330 V210',LAYC.water,L.water&&P.tonsOut>0,sp(P.tonsOut/P.u.nom),3);
      s+=dash('M380 210 V250 H480 V310',LAYC.water,L.water&&P.tonsOut>0,sp(P.tonsOut/P.u.nom),3,'3 7');
      s+=tag(250,292,`CHWS 44 °F · CHWR 54 °F · ${f0(gpm)} gpm`,LAYC.water);
    }
    /* electrical one-line */
    s+=box(700,470,110,40,'SWITCHBOARD',LS.svc==='208'?'208Y/120 V':LS.svc==='460'?'460Y/265 V':'480Y/277 V','#3a2a10');
    s+=box(560,470,110,40,'DISCONNECT',`${E1.MOCP} A fused`,'#3a2a10');
    s+=dash('M700 490 H670 M560 490 H470 V330',LAYC.elec,L.elec,sp(E1.I/Math.max(1,E1.MCA)),3,'10 6');
    s+=tag(480,520,`${f0(E1.I)} A · ${f1(E1.kW)} kW · PF ${fmt(E1.pf,2)}`,LAYC.elec);
    /* controls */
    s+=box(940,470,140,40,'BAS FRONT END',LS.bas==='niagara'?'Niagara':LS.bas==='lon'?'LonWorks':'BACnet/IP','#2a2350');
    s+=dash('M940 490 H860 V160 H850 M940 480 H640 V250',LAYC.ctrl,L.ctrl,1.6,1.5,'2 6');
    s+=tag(870,190,'zone sensor → VAV controller',LAYC.ctrl);
    /* state tags */
    s+=tag(48,84,`OA ${f1(S.oa.db)} °F`);s+=tag(132,113,`MA ${f1(S.ma.db)} °F`);s+=tag(420,113,`SA ${f1(S.sa.db)} °F`);
    s+=tag(600,158,`${f0(P.cfm)} CFM`);s+=tag(886,360,`room ${f1(S.room.db)} °F`);s+=tag(120,425,`RA ${f1(S.ra.db)} °F`);
    if(P.o.eco)s+=`<text x="560" y="40" font-size="13" fill="#34d399" font-weight="800" text-anchor="middle">ECONOMIZER — free cooling, compressors off</text>`;
    s+=`</svg>`;
    host.innerHTML=`<div class="labCard"><h4>Flow schematic — ${chw?'chilled-water AHU':'DX rooftop unit'} <small>dash speed follows flow · values are live for the selected hour</small></h4>
      <div class="labCtl"><div class="labLayers">${Object.entries({air:'Air',ref:'Refrigerant',water:'Chilled water',elec:'Electrical',ctrl:'Controls'}).map(([k,t])=>`<button type="button" data-lay="${k}" class="${LS.layers[k]?'':'off'}" style="--c:${LAYC[k]}"><i></i>${t}</button>`).join('')}</div></div>
      <div class="labBp">${s}</div></div>
      <div class="labGrid"><div class="labCard"><h4>Working principle</h4>
        <p><b>Air side.</b> Outdoor air and return air meet in the mixing box; dampers hold the outdoor-air minimum, or open fully for free cooling when it is cool and dry enough (economizer). Air is filtered, cooled and dehumidified at the coil, and the supply fan, on a variable-frequency drive, delivers it down the main. Each VAV box throttles airflow to hold its zone set point, and the fan slows to keep duct static pressure at set point. Air returns through the ceiling plenum.</p>
        <p><b>${chw?'Water side.':'Refrigerant side.'}</b> ${chw?'The chiller cools water to 44 °F; pumps on VFDs circulate it through the AHU coil, and the control valve modulates to hold supply-air temperature. Flow is about 2.4 gpm per ton at a 10 °F rise.':'Scroll compressors raise refrigerant vapor to condensing pressure; the condenser rejects heat to outdoor air; the expansion valve drops the pressure; the evaporator coil absorbs heat from the supply air. Compressors stage on and off to match load.'}</p>
        <p><b>Controls.</b> Unit and VAV controllers talk to the building automation front end over ${LS.proto.toUpperCase()}; sequences follow ASHRAE Guideline 36.</p></div>
      <div class="labCard"><h4>Live values · ${String(LS.hour).padStart(2,'0')}:00</h4><div class="labKv">
        ${kv('Supply airflow',f0(P.cfm)+' CFM',`fan ${pct(P.flow,0)} speed`)}${kv('Capacity in use',f1(P.tonsOut)+' t',`of ${P.u.nom} t nominal`)}${kv('Stages',`${P.stages}/${P.stagesMax}`,P.o.eco?'economizer':'compressors on')}
        ${kv('Unit power',f1(P.kw)+' kW',`${fmt(P.kwPerTon,2)} kW/ton`)}${kv(LS.mode==='heat'?'COP (heating)':'EER',LS.mode==='heat'?fmt(P.cop,2):f1(P.eer),'')}${kv('Units on the job',P.u.n,`${f0(G.tonnage)} t total`)}${LS.mode==='heat'?kv('Heat-pump capacity',pct(P.capFrac,0),P.backupTons>0?`backup heat ${f1(P.backupTons)} t`:'no backup needed'):''}</div></div></div>`;
    host.querySelectorAll('[data-lay]').forEach(b=>b.addEventListener('click',()=>{LS.layers[b.dataset.lay]=!LS.layers[b.dataset.lay];renderFlow();}));
  }

  /* ================================================================ pressure–enthalpy cycle */
  let CYO={sh:10,sc:10,eta:.72};
  function renderCycle(){
    const host=$id('labCycle'),P=plant();
    const C=cycle({Te:P.cyc.Te,Tc:P.cyc.Tc,...CYO});
    const W=760,Ht=430,x0=60,x1=W-20,y0=Ht-40,y1=20,hMin=0,hMax=170,pMin=20,pMax=900;
    const X=h=>x0+(h-hMin)/(hMax-hMin)*(x1-x0),Y=p=>y0-(Math.log(p)-Math.log(pMin))/(Math.log(pMax)-Math.log(pMin))*(y0-y1);
    let liq='',vap='';for(let T=-30;T<=TCRIT-1;T+=2){liq+=(liq?'L':'M')+X(hf(T)).toFixed(1)+' '+Y(psat(T)).toFixed(1);}
    for(let T=TCRIT-1;T>=-30;T-=2){vap+='L'+X(hg(T)).toFixed(1)+' '+Y(psat(T)).toFixed(1);}
    const dome=liq+vap;
    let s=`<svg viewBox="0 0 ${W} ${Ht}" role="img" aria-label="Refrigeration cycle on a pressure–enthalpy chart">`;
    s+=`<rect width="${W}" height="${Ht}" fill="#0b1622"/>`;
    [25,50,100,200,400,800].forEach(p=>s+=`<line x1="${x0}" x2="${x1}" y1="${Y(p)}" y2="${Y(p)}" stroke="#1f3a56"/><text x="${x0-6}" y="${Y(p)+3}" font-size="9.5" fill="#7d97b3" text-anchor="end">${p}</text>`);
    for(let h=0;h<=hMax;h+=20)s+=`<line x1="${X(h)}" x2="${X(h)}" y1="${y1}" y2="${y0}" stroke="#1f3a56"/><text x="${X(h)}" y="${y0+14}" font-size="9.5" fill="#7d97b3" text-anchor="middle">${h}</text>`;
    s+=`<path d="${dome}Z" fill="rgba(124,192,245,.07)" stroke="none"/><path d="${dome}" fill="none" stroke="#7cc0f5" stroke-width="1.6"/>`;
    [0,40,80,120].forEach(T=>s+=`<line x1="${X(hf(T))}" x2="${X(hg(T))}" y1="${Y(psat(T))}" y2="${Y(psat(T))}" stroke="#7cc0f5" stroke-opacity=".25" stroke-dasharray="2 4"/><text x="${X(hg(T))+4}" y="${Y(psat(T))-3}" font-size="9" fill="#7cc0f5" fill-opacity=".7">${T} °F</text>`);
    const p1=[X(C.h1),Y(C.P1)],p2=[X(C.h2),Y(C.P2)],pg=[X(hg(C.Tc)),Y(C.P2)],p3=[X(C.h3),Y(C.P2)],p4=[X(C.h4),Y(C.P1)];
    const path=`M${p1} L${p2} L${pg} L${p3} L${p4} Z`;
    s+=`<path d="${path}" fill="rgba(244,114,182,.12)" stroke="#f472b6" stroke-width="2.4" stroke-linejoin="round"/>`;
    s+=`<path d="M${p1} L${X(C.h2s)},${Y(C.P2)}" stroke="#f472b6" stroke-opacity=".45" stroke-dasharray="3 3"/>`;
    [[p1,'1','compressor suction'],[p2,'2','discharge'],[p3,'3','liquid line'],[p4,'4','after expansion']].forEach(([p,n,t])=>s+=`<circle cx="${p[0]}" cy="${p[1]}" r="5" fill="#f472b6"/><text x="${p[0]+8}" y="${p[1]-7}" font-size="11" fill="#fbcfe8" font-weight="800">${n}</text><text x="${p[0]+8}" y="${p[1]+12}" font-size="9" fill="#f9a8d4">${t}</text>`);
    s+=`<circle r="6" fill="#fff"><animateMotion dur="5s" repeatCount="indefinite" path="${path}"/></circle>`;
    s+=`<text x="${(x0+x1)/2}" y="${Ht-6}" font-size="10" fill="#9fc2e4" text-anchor="middle">Enthalpy, Btu/lb</text><text x="14" y="${(y0+y1)/2}" font-size="10" fill="#9fc2e4" transform="rotate(-90 14 ${(y0+y1)/2})" text-anchor="middle">Pressure, psia (log)</text>`;
    s+=`<text x="${X(hf(60))-14}" y="${Y(psat(60))+30}" font-size="10" fill="#7cc0f5" text-anchor="end">sub-cooled liquid</text><text x="${X(90)}" y="${Y(psat(20))+28}" font-size="10" fill="#7cc0f5" text-anchor="middle">liquid + vapor</text><text x="${X(150)}" y="${Y(60)}" font-size="10" fill="#7cc0f5">superheated vapor</text>`;
    s+=`</svg>`;
    const heat=LS.mode==='heat',mdot=C.mdotPerTon*Math.max(P.tonsOut,1e-6);
    const rows=[['1',C.T1,C.P1,C.h1,'superheated vapor'],['2',C.T2,C.P2,C.h2,'superheated vapor'],['3',C.T3,C.P2,C.h3,'sub-cooled liquid'],['4',C.Te,C.P1,C.h4,`mix · quality ${pct(C.x4,0)}`]];
    host.innerHTML=`<div class="labGrid"><div class="labCard"><h4>Vapor-compression cycle · ${heat?'heat-pump heating':'cooling'} <small>R-454B / R-410A class · representative property fit</small></h4>
        <div class="labCtl"><label>Superheat °F<input type="range" id="cySh" min="2" max="25" step="1" value="${CYO.sh}"></label><label>Subcooling °F<input type="range" id="cySc" min="2" max="25" step="1" value="${CYO.sc}"></label><label>Compressor η<input type="range" id="cyEta" min=".5" max=".85" step=".01" value="${CYO.eta}"></label></div>
        <div class="labBp">${s}</div></div>
      <div><div class="labCard"><h4>Cycle results</h4><div class="labKv">
        ${kv('Evaporating',`${f1(C.Te)} °F`,`${f0(C.P1-14.7)} psig`)}${kv('Condensing',`${f1(C.Tc)} °F`,`${f0(C.P2-14.7)} psig`)}${kv('Compression ratio',fmt(C.ratio,2),'')}
        ${kv('Refrigerating effect',`${f1(C.RE)} Btu/lb`,'h₁ − h₄')}${kv('Compressor work',`${f1(C.W)} Btu/lb`,'h₂ − h₁')}${kv(heat?'COP heating':'COP cooling',fmt(heat?C.COPh:C.COPc,2),heat?'(h₂ − h₃)/(h₂ − h₁)':'(h₁ − h₄)/(h₂ − h₁)')}
        ${kv('Discharge temp',`${f0(C.T2)} °F`,C.T2>225?'above 225 °F guide':'within guide')}${kv('Mass flow',`${f0(mdot)} lb/min`,`${fmt(C.mdotPerTon,2)} lb/min per ton`)}${kv('Capacity now',`${f1(P.tonsOut)} t`,`${P.stages}/${P.stagesMax} stages`)}</div>
        ${tbl([['Point'],['Temp °F',1],['psig',1],['h Btu/lb',1],['State']],rows.map(r=>[`<b>${r[0]}</b>`,f1(r[1]),f0(r[2]-14.7),f1(r[3]),r[4]]))}</div>
      <div class="labCard"><h4>The four processes</h4>
        <p><b>1 → 2 Compression.</b> The scroll compressor raises suction vapor to condensing pressure; work in is h₂ − h₁ (dashed line = ideal isentropic path).</p>
        <p><b>2 → 3 Condensing.</b> The vapor desuperheats, condenses and sub-cools in the condenser, rejecting h₂ − h₃ to ${heat?'the supply air (heating)':'outdoor air'}.</p>
        <p><b>3 → 4 Expansion.</b> The expansion valve drops the pressure at constant enthalpy; some liquid flashes to vapor.</p>
        <p><b>4 → 1 Evaporating.</b> The remaining liquid boils in the evaporator, absorbing h₁ − h₄ from ${heat?'outdoor air':'the supply air'}; superheat protects the compressor from liquid.</p>
        <p style="font-size:10.5px">Property curve fitted to published R-410A-class saturation data (about ±5 %). Use the manufacturer's selection software and refrigerant tables for design.</p></div></div></div>`;
    [['cySh','sh'],['cySc','sc'],['cyEta','eta']].forEach(([id,k])=>$id(id).addEventListener('input',e=>{CYO[k]=+e.target.value;renderCycle();}));
  }

  /* ================================================================ electrical */
  let phRAF=0;
  function renderElec(){
    const host=$id('labElec'),E1=electrical(),P=E1.P,u=E1.u,V=E1.V;
    const flow=v=>Math.max(.3,2.2-1.8*v);
    const ln=(d,on,period,w=3)=>`<path d="${d}" fill="none" stroke="#f59e0b" stroke-width="${w}" ${on?`stroke-dasharray="10 7"><animate attributeName="stroke-dashoffset" from="34" to="0" dur="${period.toFixed(2)}s" repeatCount="indefinite"/></path>`:`stroke-opacity=".25"/>`}`;
    const dev=(x,y,t,sub,c='#3a2a10')=>`<g><rect x="${x}" y="${y}" width="120" height="44" rx="7" fill="${c}" stroke="#a16207"/><text x="${x+60}" y="${y+19}" font-size="10.5" fill="#fde68a" text-anchor="middle" font-weight="700">${t}</text><text x="${x+60}" y="${y+33}" font-size="9.5" fill="#fcd34d" text-anchor="middle">${sub}</text></g>`;
    let s=`<svg viewBox="0 0 1000 400" role="img" aria-label="Electrical one-line with live current">`;
    s+=`<rect width="1000" height="400" fill="#0b1622"/>`;
    s+=dev(20,30,'UTILITY',LS.svc==='208'?'Con Ed network 208Y/120':LS.svc==='460'?'spot network 460Y/265':'480Y/277 service');
    s+=dev(20,150,'SWITCHBOARD','main bus · metering');s+=dev(20,270,'FEEDER',`MCA ${f0(E1.MCA)} A conductors`);
    s+=ln('M80 74 V150 M80 194 V270 M140 292 H230',true,flow(E1.I/E1.MCA));
    s+=dev(230,270,'DISCONNECT',`fused ${E1.MOCP} A`);
    s+=ln('M350 292 H400 V60 H440 M400 140 H440 M400 220 H440 M400 300 H440 M400 360 H440',true,flow(E1.I/E1.MCA),2.5);
    const comp=(i,y)=>{const onS=i<P.stages;return dev(440,y,`COMPRESSOR ${i+1}`,onS?`${f1(E1.RLA*(i===P.stages-1?Math.max(.3,P.frac):1))} A · RLA ${f1(E1.RLA)}`:'off · contactor open',onS?'#3a2a10':'#1c2533');};
    s+=comp(0,38);s+=comp(1,118);if(u.comps>2){s+=dev(600,38,'COMPRESSOR 3',2<P.stages?`${f1(E1.RLA)} A`:'off',2<P.stages?'#3a2a10':'#1c2533');s+=dev(600,118,'COMPRESSOR 4',3<P.stages?`${f1(E1.RLA)} A`:'off',3<P.stages?'#3a2a10':'#1c2533');s+=ln('M560 60 H600 M560 140 H600',P.stages>2,flow(.6),2);}
    s+=dev(440,198,'VFD → SUPPLY FAN',`${f1(E1.iFan)} A · ${E1.fanHP} hp · ${pct(P.flow,0)}`);
    s+=dev(440,278,'CONDENSER FANS',`${u.condFans} × 1 hp · ${f1(E1.iCond)} A`);
    s+=dev(440,348,'CONTROL XFMR','480/24 V · 0.5 kVA');
    s+=`<text x="760" y="60" font-size="11" fill="#fde68a" font-weight="800">PER-PHASE (live)</text>`;
    ['A','B','C'].forEach((ph,i)=>s+=`<text x="760" y="${84+i*22}" font-size="11" fill="#fcd34d">${ph} · ${f1(E1.vPh[i])} V · ${f1(E1.iPh[i])} A</text>`);
    s+=`<text x="760" y="160" font-size="11" fill="#fcd34d">kW ${f1(E1.kW)} · PF ${fmt(E1.pf,2)}</text><text x="760" y="182" font-size="11" fill="#fcd34d">kVA ${f1(E1.kW/Math.max(.01,E1.pf))}</text><text x="760" y="204" font-size="11" fill="${E1.vImb>1?'#fb923c':'#86efac'}">V imbalance ${fmt(E1.vImb,2)} %</text>`;
    s+=`</svg>`;
    host.innerHTML=`<div class="labCard"><h4>One-line · ${V===460?'460-3-60':'208/230-3-60'} unit <small>current animation speed follows load</small></h4>
        <div class="labCtl"><label>Unit nameplate<select id="elUnitV"><option value="460"${LS.unitV==='460'?' selected':''}>460 V 3φ</option><option value="208"${LS.unitV==='208'?' selected':''}>208/230 V 3φ</option></select></label>
          <label>Building service<select id="elSvc"><option value="208"${LS.svc==='208'?' selected':''}>208Y/120 V network</option><option value="460"${LS.svc==='460'?' selected':''}>460Y/265 V spot network</option><option value="480"${LS.svc==='480'?' selected':''}>480Y/277 V</option></select></label></div>
        <div class="labBp">${s}</div></div>
      <div class="labGrid"><div class="labCard"><h4>Three-phase phasors <small>voltage (solid) · current (dashed) lagging by φ = ${f0(Math.acos(cl(E1.pf,0,1))*180/Math.PI)}°</small></h4>
          <div class="labBp" style="display:grid;grid-template-columns:1fr 1.2fr;gap:6px;align-items:center"><svg id="phasor" viewBox="-120 -120 240 240" role="img" aria-label="Rotating three-phase phasor diagram"></svg><svg id="wave" viewBox="0 0 300 160" role="img" aria-label="Three-phase voltage and current waveforms"></svg></div></div>
        <div class="labCard"><h4>Nameplate & protection <small>NEC 440 / 430 method</small></h4><div class="labKv">
          ${kv('RLA per compressor',f1(E1.RLA)+' A',`${u.comps} × scroll`)}${kv('LRA',f0(E1.LRA)+' A','≈ 6.5 × RLA')}${kv('Supply fan FLA',f1(E1.fanFLA)+' A',`${E1.fanHP} hp · NEC 430.250`)}
          ${kv('MCA',f1(E1.MCA)+' A','1.25 × largest + others')}${kv('MOCP',E1.MOCP+' A',`≤ ${f0(E1.mocpMax)} A (2.25 × largest + others)`)}${kv('Running now',f1(E1.I)+' A',`${f1(E1.kW)} kW`)}</div>
          <h4 style="margin-top:6px">Temperatures & pressures</h4><div class="labKv">
          ${kv('Ambient',`${f1(P.o.oa)} °F`,`${f1(E1.ambC)} °C`)}${kv('Motor winding (est.)',`${f0(E1.winding)} °C`,'class F limit 155 °C')}${kv('Compressor discharge',`${f0(E1.discharge)} °F`,'guide < 225 °F')}
          ${kv('Suction',`${f0(E1.suctionPsig)} psig`,`${f1(P.cyc.Te)} °F sat.`)}${kv('Head',`${f0(E1.headPsig)} psig`,`${f1(P.cyc.Tc)} °F sat.`)}${kv('Supply air',`${f1(flowStates().sa.db)} °F`,'')}</div></div></div>`;
    $id('elUnitV').addEventListener('change',e=>{LS.unitV=e.target.value;renderElec();});$id('elSvc').addEventListener('change',e=>{LS.svc=e.target.value;renderElec();});
    const pf=cl(E1.pf,0,1),phi=Math.acos(pf),iMag=Math.min(1,E1.I/Math.max(1,E1.MCA));
    cancelAnimationFrame(phRAF);
    const ph=$id('phasor'),wv=$id('wave');
    const draw=t=>{
      if(!LS.open||LS.section!=='elec'||!ph.isConnected)return;
      const w=(t/1000)*2*Math.PI*.25;let a='<circle r="100" fill="none" stroke="#1f3a56"/><line x1="-110" x2="110" stroke="#1f3a56"/><line y1="-110" y2="110" stroke="#1f3a56"/>';
      const cols=['#f87171','#facc15','#60a5fa'];
      [0,1,2].forEach(k=>{const th=w-k*2*Math.PI/3,x=95*Math.cos(th),y=-95*Math.sin(th),ti=th-phi,xi=95*iMag*Math.cos(ti),yi=-95*iMag*Math.sin(ti);
        a+=`<line x2="${x.toFixed(1)}" y2="${y.toFixed(1)}" stroke="${cols[k]}" stroke-width="3"/><circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="4" fill="${cols[k]}"/><line x2="${xi.toFixed(1)}" y2="${yi.toFixed(1)}" stroke="${cols[k]}" stroke-width="2" stroke-dasharray="4 3"/><text x="${(x*1.12).toFixed(1)}" y="${(y*1.12).toFixed(1)}" font-size="10" fill="${cols[k]}" text-anchor="middle">${'ABC'[k]}</text>`;});
      ph.innerHTML=a;
      let b='<line x1="0" x2="300" y1="80" y2="80" stroke="#1f3a56"/>';
      [0,1,2].forEach(k=>{let pv='',pi='';for(let i=0;i<=300;i+=4){const th=i/300*4*Math.PI+w-k*2*Math.PI/3;pv+=(i?'L':'M')+i+' '+(80-60*Math.sin(th)).toFixed(1);pi+=(i?'L':'M')+i+' '+(80-60*iMag*Math.sin(th-phi)).toFixed(1);}
        b+=`<path d="${pv}" fill="none" stroke="${cols[k]}" stroke-width="1.6"/><path d="${pi}" fill="none" stroke="${cols[k]}" stroke-width="1.2" stroke-dasharray="3 3" opacity=".8"/>`;});
      wv.innerHTML=b+`<text x="4" y="12" font-size="9" fill="#9fc2e4">V (solid) · I (dashed) · 2 cycles, slowed for viewing</text>`;
      phRAF=requestAnimationFrame(draw);
    };
    phRAF=requestAnimationFrame(draw);
  }

  /* ================================================================ compatibility */
  function renderCompat(){
    const host=$id('labCompat'),rows=compat();
    const opt=(id,o,v)=>`<select id="${id}">${Object.entries(o).map(([k,t])=>`<option value="${k}"${String(v)===k?' selected':''}>${t}</option>`).join('')}</select>`;
    const cnt=k=>rows.filter(r=>r.status===k).length;
    host.innerHTML=`<div class="labCard"><h4>Compatibility requirements <small>change a choice and every check re-runs</small></h4>
      <div class="labCtl">
        <label>Unit nameplate${opt('cpUnitV',{460:'460 V 3φ',208:'208/230 V 3φ'},LS.unitV)}</label>
        <label>Building service${opt('cpSvc',{208:'208Y/120 V network',460:'460Y/265 V spot network',480:'480Y/277 V'},LS.svc)}</label>
        <label>Unit controller${opt('cpProto',{'bacnet-ip':'BACnet/IP','bacnet-mstp':'BACnet MS/TP',modbus:'Modbus RTU',lon:'LonWorks'},LS.proto)}</label>
        <label>BAS front end${opt('cpBas',{bacnet:'BACnet',niagara:'Niagara (multi-protocol)',lon:'LonWorks'},LS.bas)}</label>
        <label>Refrigerant${opt('cpRefr',{'R-454B':'R-454B (A2L)','R-32':'R-32 (A2L)','R-410A':'R-410A (A1)'},LS.refr)}</label>
        <label><input type="checkbox" id="cpLeak"${LS.leakDet?' checked':''}>Leak detection</label>
        <label>Roof psf<input type="number" id="cpRoof" min="10" max="150" step="5" value="${LS.roofPsf}" style="width:56px"></label>
        <label><input type="checkbox" id="cpDun"${LS.dunnage?' checked':''}>Steel dunnage</label>
        <label>Duct class<select id="cpDuct">${[1,2,3,4,6].map(v=>`<option value="${v}"${LS.ductClass===v?' selected':''}>${v} in. w.g.</option>`).join('')}</select></label>
        <label><input type="checkbox" id="cpEco"${LS.economizer?' checked':''}>Economizer</label>
        <label>Heating${opt('cpHeat',{hp:'Heat pump',gas:'Gas'},LS.heat)}</label>
      </div>
      <div class="labKv">${kv('Pass',cnt('pass'),'')}${kv('Watch',cnt('watch'),'')}${kv('Fail',cnt('fail'),'')}</div>
      <div class="scrollX">${tbl([['Area'],['Requirement'],['Status'],['Finding'],['Basis']],rows.map(r=>[`<b>${esc(r.group)}</b>`,esc(r.item),pill(r.status),esc(r.detail),`<small>${esc(r.basis)}</small>`]))}</div>
      <p style="margin-top:8px;font-size:10.5px">Representative checks for a public demonstration. Confirm against the adopted code editions, the manufacturer's submittal data and the engineer of record — not sealed design, not official agency approval.</p></div>`;
    const bind=(id,fn,ev='change')=>$id(id).addEventListener(ev,e=>{fn(e.target);renderCompat();});
    bind('cpUnitV',t=>LS.unitV=t.value);bind('cpSvc',t=>LS.svc=t.value);bind('cpProto',t=>LS.proto=t.value);bind('cpBas',t=>LS.bas=t.value);bind('cpRefr',t=>LS.refr=t.value);
    bind('cpLeak',t=>LS.leakDet=t.checked);bind('cpRoof',t=>LS.roofPsf=+t.value||30,'input');bind('cpDun',t=>LS.dunnage=t.checked);bind('cpDuct',t=>LS.ductClass=+t.value);
    bind('cpEco',t=>LS.economizer=t.checked);bind('cpHeat',t=>LS.heat=t.value);
  }

  /* ================================================================ testing & commissioning */
  function renderCx(){
    const host=$id('labCx'),rows=cxStatus(),D=PLAN.duration;
    const col={Pass:'#178655','Fail / retest':'#b42318',Due:'#b45309',Scheduled:'#64748b'};
    let tl=`<svg viewBox="0 0 1000 120" role="img" aria-label="Commissioning timeline on the schedule"><rect width="1000" height="120" fill="#0b1622"/>`;
    const X=d=>30+(d-1)/(D-1)*940;
    tl+=`<line x1="30" x2="970" y1="70" y2="70" stroke="#385d80" stroke-width="2"/>`;
    [1,Math.round(D/4),Math.round(D/2),Math.round(3*D/4),D].forEach(d=>tl+=`<text x="${X(d)}" y="108" font-size="10" fill="#7d97b3" text-anchor="middle">D${d}</text>`);
    tl+=`<line x1="${X(SIM.day)}" x2="${X(SIM.day)}" y1="18" y2="92" stroke="#e0b65a" stroke-dasharray="3 3"/><text x="${X(SIM.day)+4}" y="26" font-size="10" fill="#e0b65a">today D${SIM.day}</text>`;
    rows.forEach((r,i)=>{const x=X(r.due),y=i%2?50:88;tl+=`<circle cx="${x}" cy="70" r="7" fill="${col[r.status]}"/><text x="${x}" y="${y}" font-size="10" fill="#e8eef4" text-anchor="middle" font-weight="700">${r.id}</text>`;});
    tl+=`</svg>`;
    host.innerHTML=`<div class="labCard"><h4>Testing &amp; commissioning on the schedule clock <small>tests run when the playback day reaches them, or press Run</small></h4>
      <div class="labBp">${tl}</div>
      <div class="labKv" style="margin-top:8px">${kv('Passed',rows.filter(r=>r.status==='Pass').length+' / '+rows.length,'')}${kv('Retest',rows.filter(r=>r.status==='Fail / retest').length,'')}${kv('Due soon',rows.filter(r=>r.status==='Due').length,'')}${kv('Cx window',`D${actWindow('A14').s}–D${actWindow('A14').f}`,'startup & commissioning')}</div>
      <div class="scrollX">${tbl([['#'],['Stage'],['Test'],['Standard'],['Benchmark (acceptance)'],['Due',1],['Measured'],['Status'],['']],rows.map(r=>[`<b>${r.id}</b>`,esc(r.stage),esc(r.test),`<small>${esc(r.std)}</small>`,`<small>${esc(r.bench)}</small>`,`D${r.due}<br><small>${simDate(r.due)}</small>`,r.m?esc(r.m.txt):'—',`<span class="labPill" style="background:${col[r.status]}">${esc(r.status)}</span>`,`<button class="hbtn" type="button" data-cxrun="${r.id}">${r.run?'Re-run':'Run'}</button>`]))}</div>
      <p style="margin-top:8px;font-size:10.5px">Benchmarks are typical acceptance criteria drawn from the cited standards and common specifications. The project specification, manufacturer instructions and the commissioning authority's plan govern.</p></div>`;
    host.querySelectorAll('[data-cxrun]').forEach(b=>b.addEventListener('click',()=>{const k=b.dataset.cxrun;LS.cxRun[k]=(LS.cxRun[k]||0)+1;renderCx();const r=cxStatus().find(x=>x.id===k);snd(r&&r.pass?'success':'alert');}));
  }

  /* ================================================================ duty cycles */
  function renderDuty(){
    const host=$id('labDuty'),d=duty(),R=d.rows;
    const W=980,Ht=330,x0=50,x1=W-50,y0=Ht-36,y1=16,X=h=>x0+(h+.5)/24*(x1-x0),bw=(x1-x0)/24*.7;
    const oaMin=Math.min(...R.map(r=>r.oa))-5,oaMax=Math.max(...R.map(r=>r.oa))+5,Yt=v=>y0-(v-oaMin)/(oaMax-oaMin)*(y0-y1);
    const kwMax=Math.max(1,...R.map(r=>r.kw)),Yk=v=>y0-v/kwMax*(y0-y1)*.9;
    const sMax=R[0]?plant(0).stagesMax:4,Ys=v=>y0-v/sMax*(y0-y1)*.55;
    let s=`<svg viewBox="0 0 ${W} ${Ht}" role="img" aria-label="Design-day duty cycle"><rect width="${W}" height="${Ht}" fill="#0b1622"/>`;
    for(let h=0;h<24;h+=3)s+=`<text x="${X(h)}" y="${Ht-16}" font-size="10" fill="#7d97b3" text-anchor="middle">${String(h).padStart(2,'0')}:00</text>`;
    R.forEach(r=>{s+=`<rect x="${X(r.h)-bw/2}" y="${Ys(r.stages)}" width="${bw}" height="${y0-Ys(r.stages)}" fill="${r.eco?'#34d39955':'#2f8fe066'}"/>`;
      if(r.startsPerHr>0)s+=`<rect x="${X(r.h)-3}" y="${y0-r.startsPerHr*6}" width="6" height="${r.startsPerHr*6}" fill="${r.startsPerHr>6?'#f87171':'#f472b6'}"/>`;
      if(r.defrost)s+=`<text x="${X(r.h)}" y="${y1+12}" font-size="10" fill="#93c5fd" text-anchor="middle">❄</text>`;});
    s+=`<polyline points="${R.map(r=>`${X(r.h)},${Yt(r.oa)}`).join(' ')}" fill="none" stroke="#e0b65a" stroke-width="2.2"/>`;
    s+=`<polyline points="${R.map(r=>`${X(r.h)},${Yk(r.kw)}`).join(' ')}" fill="none" stroke="#f59e0b" stroke-width="1.6" stroke-dasharray="5 4"/>`;
    s+=`<line x1="${X(LS.hour)}" x2="${X(LS.hour)}" y1="${y1}" y2="${y0}" stroke="#fff" stroke-opacity=".5" stroke-dasharray="2 3"/>`;
    s+=`<text x="${x0}" y="${y1+2}" font-size="10" fill="#e0b65a">outdoor °F ${f0(oaMin+5)}–${f0(oaMax-5)}</text><text x="${x1}" y="${y1+2}" font-size="10" fill="#f59e0b" text-anchor="end">unit kW (dashed) · peak ${f1(kwMax)}</text></svg>`;
    host.innerHTML=`<div class="labCard"><h4>Duty &amp; heat cycles · ${LS.mode==='heat'?`heat-pump heating at ${LS.winterOA} °F design`:'cooling design day'} <small>bars = compressor stages · pink = starts per hour · green = economizer · ❄ = defrost window</small></h4>
      <div class="labBp">${s}</div>
      <div class="labKv" style="margin-top:8px">${kv('Unit energy',f0(d.kwh)+' kWh/day','per unit')}${kv('Job energy',f0(d.kwh*unit().n)+' kWh/day',`${unit().n} units`)}${kv('Max starts / hour',f1(d.maxStarts),'anti-short-cycle limit 6')}${kv('Compressor starts',f0(d.starts),'per unit per day')}${kv('Economizer hours',R.filter(r=>r.eco).length,'')}${LS.mode==='heat'?kv('Backup heat hours',R.filter(r=>r.backup>.05).length,'heat pump below load'):''}${kv(LS.mode==='heat'?'Defrost hours':'Avg COP',LS.mode==='heat'?R.filter(r=>r.defrost).length:fmt(R.filter(r=>r.stages).reduce((s,r)=>s+r.cop,0)/Math.max(1,R.filter(r=>r.stages).length),2),'')}</div>
      <p>The top compressor stage cycles when demand sits between stages; starts per hour peak when that stage runs about half the time. Minimum on / off timers (typically 3–5 minutes) cap the rate near 6 starts per hour. Heat pumps defrost the outdoor coil when it frosts, most often between about 17 °F and 40 °F in humid air.</p></div>`;
  }

  /* ================================================================ 3D exploded system */
  css(`
    .lab3dWrap{display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:12px;align-items:stretch}
    @media(max-width:1100px){.lab3dWrap{grid-template-columns:1fr}}
    #lab3dView{position:relative;height:calc(100vh - 150px);min-height:420px;border-radius:14px;overflow:hidden;background:radial-gradient(ellipse at 50% 35%,#1b3350,#0b1622 70%);border:1px solid var(--line)}
    #lab3dView canvas{display:block;width:100%;height:100%;cursor:grab;touch-action:none}
    #lab3dView canvas.drag{cursor:grabbing}
    .v3Bar{position:absolute;left:10px;top:10px;right:120px;display:flex;flex-wrap:wrap;gap:4px;z-index:3}
    .v3Bar button{all:unset;cursor:pointer;font:700 10.5px var(--mono);color:#d8ebff;background:rgba(11,22,34,.72);border:1px solid #385d80;border-radius:7px;padding:4px 8px}
    .v3Bar button.on{background:#2f8fe0;border-color:#2f8fe0;color:#fff}
    .v3Bar button:focus-visible{outline:2px solid #e0b65a}
    .v3Bar .sep{width:8px}
    .v3Explode{position:absolute;left:10px;bottom:10px;z-index:3;display:flex;gap:8px;align-items:center;background:rgba(11,22,34,.72);border:1px solid #385d80;border-radius:10px;padding:6px 10px;color:#d8ebff;font:700 10.5px var(--mono)}
    .v3Explode input{width:200px}
    .v3Hint{position:absolute;right:10px;bottom:10px;z-index:3;font:600 10px var(--mono);color:#9fc2e4;background:rgba(11,22,34,.6);border-radius:8px;padding:5px 8px;max-width:330px;text-align:right}
    .v3Labels{position:absolute;inset:0;pointer-events:none;z-index:2}
    .v3Lbl{position:absolute;transform:translate(-50%,-100%);font:700 10px var(--mono);color:#e8eef4;background:rgba(11,22,34,.78);border:1px solid #385d80;border-radius:6px;padding:2px 6px;white-space:nowrap;pointer-events:auto;cursor:pointer}
    .v3Lbl.sel{border-color:#e0b65a;color:#fde68a}
    .v3Lbl::after{content:"";position:absolute;left:50%;top:100%;width:1px;height:10px;background:#7cc0f5}
    /* ViewCube */
    .vcWrap{position:absolute;right:16px;top:14px;width:86px;height:110px;z-index:4;perspective:340px}
    .vc{position:absolute;left:8px;top:6px;width:70px;height:70px;transform-style:preserve-3d}
    .vc div{position:absolute;width:70px;height:70px;display:flex;align-items:center;justify-content:center;font:800 9.5px var(--mono);letter-spacing:.06em;color:#0b1622;background:rgba(216,235,255,.9);border:1px solid #385d80;cursor:pointer;backface-visibility:hidden;user-select:none}
    .vc div:hover{background:#e0b65a}
    .vcHome{position:absolute;left:0;top:88px;display:flex;gap:4px}
    .vcHome button{all:unset;cursor:pointer;font:700 9.5px var(--mono);color:#d8ebff;background:rgba(11,22,34,.72);border:1px solid #385d80;border-radius:6px;padding:2px 6px}
    #v3Info h5{margin:0 0 2px;font-size:15px}#v3Info .sub{font-size:11px;color:var(--muted);margin-bottom:8px}
    #v3Info p{font-size:12px;line-height:1.5;margin:0 0 8px;color:var(--text)}
    #v3Info table{font-size:11.5px}
    .v3Parts{display:flex;flex-wrap:wrap;gap:4px;margin-top:6px}
    .v3Parts button{all:unset;cursor:pointer;font:600 10.5px var(--mono);border:1px solid var(--line);border-radius:999px;padding:2px 8px}
    .v3Parts button.on{background:var(--blue);color:#fff;border-color:var(--blue)}
  `);
  const V3={ok:false,parts:[],byKey:{},explode:0,raf:0,anim:null,proj:'persp',view:'iso3',sel:null,isolate:false,particles:true};
  const INFO={
    casing:{n:'Cabinet panels',g:'Unit',p:'Double-wall insulated casing with removable access panels. In x-ray or exploded view the panels lift away to show the airstream.',std:'UL 1995 / UL 60335-2-40 · AHRI 340/360 cabinet leakage',v:()=>[['Unit',`${unit().nom} ton nominal`],['Operating weight',`${f0(unit().weight)} lb`]]},
    oa:{n:'Outdoor-air hood & economizer dampers',g:'Air',p:'Opposed-blade dampers hold the ventilation minimum and open fully for free cooling when outdoor air is cool enough. The relief damper keeps the building pressure neutral.',std:'ASHRAE 62.1 ventilation · ASHRAE 90.1 economizer · AMCA 511',v:()=>{const P=plant();return [['Outdoor air',`${f1(P.o.oa)} °F`],['Mode',P.o.eco?'economizer (100 % OA)':'minimum OA']];}},
    ret:{n:'Return-air damper',g:'Air',p:'Return air from the ceiling plenum enters through the curb and mixes with outdoor air.',std:'SMACNA · AMCA 500-D',v:()=>[['Return air',`${f1(flowStates().ra.db)} °F`]]},
    filter:{n:'Filter bank',g:'Air',p:'Pleated filters clean the mixed air before the coil; pressure drop rises as they load, so the fan works harder.',std:'ASHRAE 52.2 (MERV 13) · ASHRAE 62.1 minimum MERV 8',v:()=>[['Rating','MERV 13'],['Clean / dirty Δp','0.35 / 1.0 in. w.g.']]},
    coil:{n:LS.sys==='chw'?'Chilled-water coil':'DX evaporator coil',g:'Thermal',p:LS.sys==='chw'?'Chilled water at 44 °F absorbs heat and moisture from the air; a two-way valve modulates flow to hold supply temperature.':'Refrigerant boils inside the tubes, absorbing heat and moisture from the air flowing across the fins. Condensate drains to the sloped pan.',std:'AHRI 410 (coils) · ASHRAE 62.1 drain pan',v:()=>{const P=plant(),S=flowStates();return [['Air in / out',`${f1(S.ma.db)} → ${f1(S.sa.db)} °F`],['Evaporating',`${f1(P.cyc.Te)} °F`],['Load',`${f1(P.tonsOut)} t`]];}},
    heat:{n:'Heating section',g:'Thermal',p:'On a heat-pump unit, the reversing valve swaps the coils for heating; gas or electric heat is the alternative.',std:'AHRI 340/360 · ANSI Z21.47 (gas)',v:()=>[['Type',LS.heat==='hp'?'heat pump':'gas']]},
    fan:{n:'Supply fan & motor',g:'Air',p:'A direct-drive plenum fan on a VFD. Flow follows speed, pressure follows speed², power follows speed³ (fan laws).',std:'AMCA 210 · ASHRAE 90.1 fan power · NEMA Premium motors',v:()=>{const P=plant(),E1=electrical();return [['Airflow',`${f0(P.cfm)} CFM`],['Speed',pct(P.flow,0)],['Power',`${f1(P.kwFan)} kW`],['Motor',`${E1.fanHP} hp · ${f1(E1.iFan)} A`]];}},
    vfd:{n:'Variable-frequency drive',g:'Electrical',p:'Converts fixed 60 Hz to variable frequency so the fan slows at part load. Harmonics are limited at the point of common coupling.',std:'IEEE 519 harmonics · UL 61800-5-1 · NEC 430',v:()=>{const P=plant();return [['Output',`${f0(60*P.flow)} Hz`],['Efficiency','≈ 97 %']];}},
    comp:{n:'Scroll compressors',g:'Refrigerant',p:'Tandem scroll compressors stage on and off to match load; the anti-short-cycle timer limits starts to about 6 per hour.',std:'UL 60335-2-34 · AHRI 540 performance',v:()=>{const P=plant(),E1=electrical();return [['Running',`${P.stages}/${P.stagesMax}`],['RLA',`${f1(E1.RLA)} A each`],['Suction / head',`${f0(E1.suctionPsig)} / ${f0(E1.headPsig)} psig`],['Discharge',`${f0(E1.discharge)} °F`]];}},
    cond:{n:'Condenser coil',g:'Refrigerant',p:'Hot refrigerant gas condenses inside the tubes, rejecting heat to outdoor air drawn across the fins.',std:'AHRI 340/360 rating conditions (95 °F ambient)',v:()=>{const P=plant();return [['Condensing',`${f1(P.cyc.Tc)} °F`],['Ambient',`${f1(P.o.oa)} °F`]];}},
    cfans:{n:'Condenser fans',g:'Refrigerant',p:'Propeller fans pull outdoor air up through the condenser; head-pressure control slows or stages them in cool weather.',std:'AMCA 210 · NYC Noise Control Code (verify receptors)',v:()=>{const u=unit(),E1=electrical();return [['Fans',`${u.condFans} × 1 hp`],['Current',`${f1(E1.iCond)} A`]];}},
    panel:{n:'Control panel & unit controller',g:'Controls',p:'Contactors, overloads, a 24 V control transformer and the DDC unit controller. It runs the sequence and reports to the building automation system.',std:'UL 508A · ASHRAE 135 BACnet · Guideline 36',v:()=>[['Protocol',LS.proto.toUpperCase()],['Front end',LS.bas]]},
    curb:{n:'Roof curb & dunnage',g:'Structure',p:'An insulated curb seals the roof opening; steel dunnage spreads the operating weight to the structure and raises the unit for roofing access.',std:'NYC Building Code Ch. 15–16 · ASCE 7 wind / seismic restraint',v:()=>{const u=unit();return [['Load',`${f0(u.weight/u.curbSF)} psf on ${f0(u.curbSF)} SF`],['Roof capacity',`${LS.roofPsf} psf`]];}},
    sduct:{n:'Supply duct drop & main',g:'Air',p:'Supply air drops through the roof into the ceiling-plenum main; duct static pressure is the fan control point.',std:'SMACNA duct construction & leakage · NYC Mechanical Code',v:()=>{const P=plant();return [['Airflow',`${f0(P.cfm)} CFM`],['Pressure class',`${LS.ductClass} in. w.g.`]];}},
    vav:{n:'VAV terminal unit',g:'Air',p:'A pressure-independent box: the airflow sensor and damper hold the flow the zone asks for, between minimum (ventilation) and maximum (cooling). A reheat coil warms air for heating.',std:'AHRI 880 · ASHRAE 62.1 minimum flow · Guideline 36',v:()=>{const hv=H(),sp=hv?.spaces?.()[0];return [['Zone design',sp?`${f0(sp.cfm)} CFM`:'—'],['Controller','BACnet MS/TP']];}},
    diff:{n:'Ceiling diffuser',g:'Air',p:'Throws supply air along the ceiling (Coanda effect) so it mixes before reaching people; throw and neck velocity set comfort and noise.',std:'ASHRAE 70 · ASHRAE 55 comfort · ADPI',v:()=>{const a=H()?.airStats?.();return a?[['Neck velocity',`${f0(a.vNeck)} fpm`],['Throw T50',`${f1(a.t50)} ft`]]:[];}},
    sensor:{n:'Zone sensor',g:'Controls',p:'Space temperature (and CO₂ for demand ventilation) feeds the VAV controller, which resets airflow.',std:'ASHRAE 55 · ASHRAE 62.1 DCV',v:()=>[['Room',`${f1(flowStates().room.db)} °F`]]},
    chiller:{n:'Air-cooled chiller',g:'Water',p:'Makes 44 °F chilled water for the AHU coil; its refrigerant cycle works the same way as the rooftop unit, with a shell-and-tube or brazed-plate evaporator.',std:'AHRI 550/590 · ASHRAE 90.1 Table 6.8.1-3',v:()=>{const P=plant();return [['Load',`${f1(P.tonsOut)} t`],['CHW flow',`${f0(P.tonsOut*2.4)} gpm`]];}},
    pipe:{n:LS.sys==='chw'?'Chilled-water piping':'Refrigerant piping',g:LS.sys==='chw'?'Water':'Refrigerant',p:'Suction, discharge and liquid lines connect the compressors, condenser, expansion valve and evaporator. They are hidden while the unit is exploded.',std:'ASME B31.5 refrigerant piping · ASHRAE 15',v:()=>{const E1=electrical();return [['Suction',`${f0(E1.suctionPsig)} psig`],['Liquid / head',`${f0(E1.headPsig)} psig`]];}},
    pump:{n:'Chilled-water pump',g:'Water',p:'Variable-speed pump moves water through the coil; flow follows load with differential-pressure reset.',std:'HI standards · ASHRAE 90.1 pump power',v:()=>[['Flow',`${f0(plant().tonsOut*2.4)} gpm`]]}
  };
  function buildModel(){
    const g=new THREE.Group();V3.parts=[];V3.byKey={};
    const std=(c,o={})=>new THREE.MeshStandardMaterial({color:c,metalness:o.m??.25,roughness:o.r??.62,transparent:!!o.t,opacity:o.t??1,side:o.ds?THREE.DoubleSide:THREE.FrontSide});
    const box=(w,h,d,m,x,y,z)=>{const me=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);me.position.set(x,y,z);return me;};
    const cyl=(r,h,m,x,y,z,seg=24)=>{const me=new THREE.Mesh(new THREE.CylinderGeometry(r,r,h,seg),m);me.position.set(x,y,z);return me;};
    const part=(key,children,dir,anchor,o={})=>{const grp=new THREE.Group();children.forEach(c=>grp.add(c));grp.userData.key=key;g.add(grp);
      const p={key,grp,base:grp.position.clone(),dir:new THREE.Vector3(...dir),anchor:new THREE.Vector3(...anchor),casing:!!o.casing,hideWhen:o.hideWhen||null,spin:o.spin||[]};
      grp.traverse(m=>{if(m.isMesh){m.userData.key=key;m.userData.baseOp=m.material.opacity;m.userData.baseTr=m.material.transparent;}});
      V3.parts.push(p);(V3.byKey[key]||(V3.byKey[key]=[])).push(p);return p;};
    const chw=LS.sys==='chw';
    /* roof deck (context, not a part) */
    const deck=box(46,.5,24,std(0x2c3540,{t:.55}),3,-.25,0);g.add(deck);
    const ceil=box(30,.12,18,std(0x8fa3b5,{t:.18}),14,-8.2,0);g.add(ceil);
    /* curb & dunnage */
    part('curb',[box(19,.8,7.6,std(0x3a3f45),-.5,.4,0),box(.5,1.2,9,std(0x8a5a2b),-8,.2,0),box(.5,1.2,9,std(0x8a5a2b),7,.2,0)],[0,-1.5,0],[-.5,1,4]);
    /* casing */
    part('casing',[box(19,.25,7.2,std(0x9fb3c8,{t:.96}),-.5,5.6,0)],[0,7,0],[-4,5.8,0],{casing:true});
    part('casing',[box(19,4.8,.2,std(0xb7c6d6,{t:.96}),-.5,3.2,3.6)],[0,0,6],[-.5,3.2,3.7],{casing:true});
    part('casing',[box(19,4.8,.2,std(0xb7c6d6,{t:.96}),-.5,3.2,-3.6)],[0,0,-6],[-.5,3.2,-3.7],{casing:true});
    /* outdoor-air hood with louvers */
    const hood=[box(1.2,3.4,6.6,std(0x7d8ea0,{t:.9}),-10.6,3.4,0)];for(let i=0;i<6;i++)hood.push(box(.15,.08,6.4,std(0xd8ebff),-11.2,1.9+i*.55,0));
    part('oa',hood,[-5,0,0],[-11,5.4,0]);
    part('ret',[box(1.6,.3,5.6,std(0x5c6b7a),-8.4,1.05,0)],[0,-2.2,-2],[-8.4,1.2,0]);
    const fl=[];for(let i=0;i<5;i++)fl.push(box(.5,3.8,1.25,std(0xf2f2e9,{r:.95,m:0}),-6.6,3.2,-2.6+i*1.3));
    part('filter',fl,[0,5,0],[-6.6,5.2,0]);
    const coil=[box(1,3.8,6.4,std(0x96541f,{m:.6,r:.35}),-4.6,3.2,0)];for(let i=0;i<10;i++)coil.push(box(1.05,.05,6.45,std(0xd7dde4,{m:.8,r:.3}),-4.6,1.5+i*.38,0));
    part('coil',coil,[0,6,0],[-4.6,5.3,0]);
    part('heat',[box(.9,3.6,6.2,std(chw?0x6b7a89:0xb45309,{m:.4}),-3.1,3.2,0)],[0,4,0],[-3.1,5.2,0]);
    const wheel=new THREE.Group();wheel.position.set(-1,3.2,0);
    const hub=cyl(1.65,1.2,std(0x4b5563,{m:.7,r:.3}),0,0,0,32);hub.rotation.z=Math.PI/2;wheel.add(hub);
    for(let i=0;i<10;i++){const b=box(.9,.08,1.4,std(0xcbd5e1,{m:.7}),0,0,0);b.rotation.x=i/10*Math.PI*2;b.position.set(0,Math.sin(i/10*Math.PI*2)*1.3,Math.cos(i/10*Math.PI*2)*1.3);wheel.add(b);}
    const motor=cyl(.7,1.4,std(0x1f6fb2,{m:.5}),.9,3.2,0,24);motor.rotation.z=Math.PI/2;
    part('fan',[wheel,motor],[0,3.5,0],[-1,5.4,0],{spin:[[wheel,'x','fan']]});
    part('vfd',[box(1.1,1.6,.5,std(0x334155),1.1,2.2,3.1),box(.5,.25,.05,std(0x22c55e),1.1,2.7,3.38)],[0,0,4],[1.1,3.2,3.2]);
    if(!chw){
      const cs=[];for(let i=0;i<unit().comps;i++){const c=cyl(.55,1.6,std(0x111827,{m:.55,r:.4}),2.6+(i%2)*1.3,1.8,-1.4+Math.floor(i/2)*2.4,20);cs.push(c);}
      part('comp',cs,[0,0,5.5],[3.2,3,0]);
      part('cond',[(()=>{const m=box(.3,3.6,6.6,std(0x8f5a2d,{m:.6,r:.35}),5.4,3.6,0);m.rotation.z=.32;return m;})(),(()=>{const m=box(.3,3.6,6.6,std(0x8f5a2d,{m:.6,r:.35}),7.6,3.6,0);m.rotation.z=-.32;return m;})()],[0,7.5,0],[6.5,5.6,0]);
      const fans=[];const fanGroups=[];for(let i=0;i<2;i++){const fg=new THREE.Group();fg.position.set(6.5,5.95,-1.8+i*3.6);const ring=cyl(1.35,.25,std(0x334155),0,0,0,32);fg.add(ring);
        for(let k=0;k<4;k++){const bl=box(1.1,.04,.32,std(0xe5e7eb,{m:.6}),0,.15,0);bl.rotation.y=k*Math.PI/2;bl.position.set(Math.cos(k*Math.PI/2)*.55,.15,Math.sin(k*Math.PI/2)*.55);fg.add(bl);}fans.push(fg);fanGroups.push([fg,'y','cond']);}
      part('cfans',fans,[0,10,0],[6.5,6.6,0],{spin:fanGroups});
      /* refrigerant piping (hidden when exploded) */
      const pip=std(0xf472b6,{m:.6,r:.3});
      const tube=(a,b)=>{const A=new THREE.Vector3(...a),B=new THREE.Vector3(...b),L=A.distanceTo(B),m=cyl(.08,L,pip,0,0,0,8);m.position.copy(A.clone().add(B).multiplyScalar(.5));m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),B.clone().sub(A).normalize());return m;};
      part('pipe',[tube([3.2,2.6,0],[5.4,2.6,0]),tube([7.6,1.8,0],[7.6,1.2,1.5]),tube([7.6,1.2,1.5],[-4.6,1.2,1.5]),tube([-4.6,4.9,-1.5],[3.2,4.9,-1.5]),tube([3.2,4.9,-1.5],[3.2,2.6,0])],[0,0,0],[0,1.2,1.5],{hideWhen:'explode'});
    }else{
      const ch=[box(9,4,5,std(0x9fb3c8),6,2.6,-13),cyl(.9,7,std(0x1f6fb2,{m:.5}),6,1.2,-11.2,24)];ch[1].rotation.z=Math.PI/2;
      for(let i=0;i<3;i++)ch.push(cyl(1,.3,std(0x334155),3.4+i*2.6,4.7,-13,24));
      part('chiller',ch,[0,0,-6],[6,5.2,-13]);
      part('pump',[cyl(.5,1,std(0x16a34a,{m:.5}),1.5,.9,-8.5,20),box(1,.6,.6,std(0x15803d),1.5,.3,-8.5)],[3,0,-3],[1.5,1.6,-8.5]);
      const wat=std(0x34d399,{m:.5,r:.35});
      const tube=(a,b)=>{const A=new THREE.Vector3(...a),B=new THREE.Vector3(...b),L=A.distanceTo(B),m=cyl(.16,L,wat,0,0,0,10);m.position.copy(A.clone().add(B).multiplyScalar(.5));m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),B.clone().sub(A).normalize());return m;};
      part('pipe',[tube([-4.6,1.4,-3.6],[-4.6,1.4,-8.5]),tube([-4.6,1.4,-8.5],[1.5,1.4,-8.5]),tube([2,1.4,-11.2],[1.5,1.4,-8.5]),tube([-4.2,4.8,-3.6],[-4.2,4.8,-10]),tube([-4.2,4.8,-10],[1.6,4.8,-10.4])],[0,0,0],[-2,4.8,-8],{hideWhen:'explode'});
      part('cond',[box(.1,.1,.1,std(0x000000,{t:0}),0,0,0)],[0,0,0],[0,0,0]);V3.byKey.cond[0].grp.visible=false;
    }
    part('panel',[box(1.4,2.6,.4,std(0x475569),7.9,2.6,3.2),box(.9,.6,.05,std(0x0ea5e9),7.9,3.2,3.42)],[0,0,6],[7.9,4,3.3]);
    /* downstream: supply drop, main, VAV, diffuser, sensor */
    part('sduct',[box(2.2,8.2,2.2,std(0x8fa3b5,{m:.5,r:.4}),9.6,-3.4,0),box(8,1.6,2.2,std(0x8fa3b5,{m:.5,r:.4}),13.2,-7.2,0)],[2.5,-1.5,0],[11,-6,0]);
    part('vav',[box(2.6,1.3,1.7,std(0xc2724a,{m:.3}),18.4,-7.2,0),box(.6,1.2,1.8,std(0xb45309),19.9,-7.2,0),box(.5,.6,.3,std(0x0f172a),18.2,-6.3,.9)],[3.5,-1,0],[18.6,-6.2,0]);
    part('diff',[box(2,.12,2,std(0xe8eef4,{m:.2,r:.5}),21.6,-8.25,0),cyl(.5,.9,std(0xcbd5e1),21.6,-7.75,0,20),(()=>{const f=cyl(.42,1.6,std(0x94a3b8),20.85,-7.5,0,14);f.rotation.z=Math.PI/2;return f;})()],[1.5,-3.5,0],[21.6,-8.4,0]);
    part('sensor',[box(.5,.7,.15,std(0xf8fafc),24.5,-11,4.5)],[2,0,1],[24.5,-10.5,4.5]);
    const wall=box(.2,6,10,std(0x8fa3b5,{t:.12}),25,-11.2,2);g.add(wall);
    return g;
  }
  /* airflow + refrigerant particle paths */
  const AIRPATH=[[-12,3.4,0],[-10,3.2,0],[-7,3.2,0],[-4.6,3.2,0],[-1,3.2,0],[3,3.2,0],[8.5,3.2,0],[9.6,1,0],[9.6,-6.8,0],[17,-7.2,0],[21.6,-7.6,0],[21.6,-9.6,0],[23,-12,0]];
  const REFPATH=[[3.2,2.6,0],[5.4,2.6,0],[6.5,4.6,0],[7.6,1.8,0],[7.6,1.2,1.5],[-4.6,1.2,1.5],[-4.6,4.9,-1.5],[3.2,4.9,-1.5],[3.2,2.6,0]];
  function pathAt(pts,t){const seg=[];let L=0;for(let i=1;i<pts.length;i++){const d=Math.hypot(pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1],pts[i][2]-pts[i-1][2]);seg.push(d);L+=d;}
    let s=((t%1)+1)%1*L;for(let i=0;i<seg.length;i++){if(s<=seg[i]){const f=s/seg[i],a=pts[i],b=pts[i+1];return [a[0]+(b[0]-a[0])*f,a[1]+(b[1]-a[1])*f,a[2]+(b[2]-a[2])*f];}s-=seg[i];}return pts[pts.length-1];}
  function makeParticles(n,color,size){const geo=new THREE.BufferGeometry(),pos=new Float32Array(n*3);geo.setAttribute('position',new THREE.BufferAttribute(pos,3));
    const pts=new THREE.Points(geo,new THREE.PointsMaterial({color,size,transparent:true,opacity:.9,depthWrite:false}));pts.userData.seed=[...Array(n)].map((_,i)=>[i/n,(seeded(91+i)()-.5)]);return pts;}

  function init3D(host){
    if(V3.ok)return true;
    if(typeof THREE==='undefined'){host.innerHTML='<div style="padding:30px;color:#d8ebff">3D needs Three.js, which did not load. The 2D sections still work.</div>';return false;}
    const cv=document.createElement('canvas');host.prepend(cv);
    let r;try{r=new THREE.WebGLRenderer({canvas:cv,antialias:true,alpha:true});}catch(e){host.insertAdjacentHTML('beforeend','<div style="padding:30px;color:#d8ebff">WebGL is not available in this browser.</div>');return false;}
    r.setPixelRatio(Math.min(2,window.devicePixelRatio||1));
    const sc=new THREE.Scene();
    sc.add(new THREE.HemisphereLight(0xdbeafe,0x1e293b,.95));
    const d1=new THREE.DirectionalLight(0xffffff,.85);d1.position.set(18,30,22);sc.add(d1);const d2=new THREE.DirectionalLight(0x93c5fd,.35);d2.position.set(-20,10,-18);sc.add(d2);
    const grid=new THREE.GridHelper(80,40,0x2f4a66,0x1b2d42);grid.position.y=-12.05;sc.add(grid);
    Object.assign(V3,{ok:true,r,sc,cv,host,camP:new THREE.PerspectiveCamera(38,1,.1,600),camO:new THREE.OrthographicCamera(-10,10,10,-10,-500,500),
      target:new THREE.Vector3(4,-1.5,0),theta:Math.PI/4.2,phi:1.05,dist:50,ray:new THREE.Raycaster(),last:performance.now()});
    V3.cam=V3.camP;
    rebuild();
    bindControls(cv);
    V3.resize();
    return true;
  }
  function rebuild(){
    if(V3.model){V3.sc.remove(V3.model);V3.model.traverse(o=>{o.geometry?.dispose?.();o.material?.dispose?.();});}
    if(V3.air){V3.sc.remove(V3.air);V3.sc.remove(V3.ref);}
    INFO.coil.n=LS.sys==='chw'?'Chilled-water coil':'DX evaporator coil';
    V3.model=buildModel();V3.sc.add(V3.model);
    V3.air=makeParticles(260,0x7cc0f5,.32);V3.ref=makeParticles(90,0xf472b6,.26);V3.sc.add(V3.air);V3.sc.add(V3.ref);
    rebuild3D=false;labels();
  }
  V3.resize=()=>{if(!V3.ok)return;const w=V3.host.clientWidth||800,h=V3.host.clientHeight||500;V3.r.setSize(w,h,false);V3.camP.aspect=w/h;V3.camP.updateProjectionMatrix();V3.aspect=w/h;};
  function placeCam(){
    const s=Math.sin(V3.phi),pos=new THREE.Vector3(V3.dist*s*Math.sin(V3.theta),V3.dist*Math.cos(V3.phi),V3.dist*s*Math.cos(V3.theta)).add(V3.target);
    const ortho=V3.proj!=='persp';V3.cam=ortho?V3.camO:V3.camP;
    V3.cam.position.copy(pos);
    const up=Math.abs(Math.cos(V3.phi))>.999?new THREE.Vector3(-Math.sin(V3.theta),0,-Math.cos(V3.theta)):new THREE.Vector3(0,1,0);V3.cam.up.copy(up);
    V3.cam.lookAt(V3.target);
    if(ortho){const hh=V3.dist*Math.tan(19*Math.PI/180),a=V3.aspect||1.6;Object.assign(V3.camO,{left:-hh*a,right:hh*a,top:hh,bottom:-hh});V3.camO.updateProjectionMatrix();}
    const cube=$id('vcCube');if(cube)cube.style.transform=`translateZ(-35px) rotateX(${(V3.phi-Math.PI/2).toFixed(4)}rad) rotateY(${(-V3.theta).toFixed(4)}rad)`;
  }
  const VIEWS={front:[0,Math.PI/2,'ortho'],back:[Math.PI,Math.PI/2,'ortho'],right:[Math.PI/2,Math.PI/2,'ortho'],left:[-Math.PI/2,Math.PI/2,'ortho'],top:[0,.0005,'ortho'],bottom:[0,Math.PI-.0005,'ortho'],
    axo:[Math.PI/4,Math.acos(1/Math.sqrt(3)),'ortho'],iso3:[Math.PI/4.2,1.05,'persp']};
  function goView(k,instant){
    const v=VIEWS[k];if(!v)return;V3.view=k;
    let dth=v[0]-V3.theta;dth=Math.atan2(Math.sin(dth),Math.cos(dth));
    const from={th:V3.theta,ph:V3.phi},to={th:V3.theta+dth,ph:v[1]};V3.proj=v[2];
    if(instant){V3.theta=to.th;V3.phi=to.ph;placeCam();toolbar();return;}
    V3.anim={t0:performance.now(),dur:480,from,to};snd('layout');toolbar();
  }
  function bbox(keys){const b=new THREE.Box3();V3.parts.forEach(p=>{if(!p.grp.visible)return;if(keys&&!keys.includes(p.key))return;b.expandByObject(p.grp);});return b;}
  function fit(keys){const b=bbox(keys);if(b.isEmpty())return;const c=b.getCenter(new THREE.Vector3()),s=b.getSize(new THREE.Vector3()).length();
    V3.anim={t0:performance.now(),dur:450,from:{th:V3.theta,ph:V3.phi,tg:V3.target.clone(),d:V3.dist},to:{th:V3.theta,ph:V3.phi,tg:c,d:Math.max(8,s*1.05/(2*Math.tan(19*Math.PI/180)))}};}
  function home(){V3.target.set(4,-1.5,0);V3.dist=50;goView('iso3');}
  function bindControls(cv){
    let drag=null,moved=0;
    cv.addEventListener('contextmenu',e=>e.preventDefault());
    cv.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY,mode:(e.button===2||e.button===1||e.shiftKey)?'pan':'orbit'};moved=0;cv.setPointerCapture(e.pointerId);cv.classList.add('drag');V3.anim=null;LS.turntable=false;toolbar();});
    cv.addEventListener('pointermove',e=>{
      if(!drag){hoverPick(e);return;}
      const dx=e.clientX-drag.x,dy=e.clientY-drag.y;drag.x=e.clientX;drag.y=e.clientY;moved+=Math.abs(dx)+Math.abs(dy);
      if(drag.mode==='orbit'){V3.theta-=dx*.0085;V3.phi=cl(V3.phi-dy*.0085,.0005,Math.PI-.0005);if(V3.proj==='ortho'&&V3.view!=='iso3'){V3.view='free';}}
      else{const h=cv.clientHeight||500,k=2*V3.dist*Math.tan(19*Math.PI/180)/h;const right=new THREE.Vector3().setFromMatrixColumn(V3.cam.matrix,0),up=new THREE.Vector3().setFromMatrixColumn(V3.cam.matrix,1);
        V3.target.addScaledVector(right,-dx*k).addScaledVector(up,dy*k);}
      placeCam();
    });
    const end=e=>{if(!drag)return;cv.classList.remove('drag');if(moved<4)pick(e);drag=null;toolbar();};
    cv.addEventListener('pointerup',end);cv.addEventListener('pointercancel',()=>{drag=null;cv.classList.remove('drag');});
    cv.addEventListener('wheel',e=>{e.preventDefault();const f=Math.exp(e.deltaY*.0011);
      const p=worldAt(e);if(p){V3.target.lerp(p,1-f);}V3.dist=cl(V3.dist*f,4,260);placeCam();snd('zoom',{dir:Math.sign(e.deltaY)});},{passive:false});
    cv.addEventListener('dblclick',e=>{const hit=rayHit(e);if(hit){select(hit.object.userData.key);const p=V3.byKey[hit.object.userData.key];fit([hit.object.userData.key]);}});
    cv.tabIndex=0;
    cv.addEventListener('keydown',e=>{const k=e.key.toLowerCase();const map={h:()=>home(),f:()=>fit(V3.sel?[V3.sel]:null),a:()=>goView('axo'),p:()=>goView('iso3'),t:()=>goView('top'),'1':()=>goView('front'),'3':()=>goView('right'),'7':()=>goView('top'),e:()=>{LS.explode=LS.explode>.5?0:1;syncExplode();},x:()=>{LS.xray=!LS.xray;toolbar();},l:()=>{LS.labels=!LS.labels;labels();toolbar();}};
      if(map[k]){map[k]();e.preventDefault();}});
  }
  function ndc(e){const r=V3.cv.getBoundingClientRect();return new THREE.Vector2(((e.clientX-r.left)/r.width)*2-1,-((e.clientY-r.top)/r.height)*2+1);}
  function rayHit(e){V3.ray.setFromCamera(ndc(e),V3.cam);const ms=[];V3.parts.forEach(p=>{if(p.grp.visible)p.grp.traverse(m=>{if(m.isMesh&&m.visible)ms.push(m);});});
    const hits=V3.ray.intersectObjects(ms,false).filter(h=>!(LS.xray&&V3.parts.find(p=>p.key===h.object.userData.key)?.casing));return hits[0]||null;}
  function worldAt(e){V3.ray.setFromCamera(ndc(e),V3.cam);const n=new THREE.Vector3();V3.cam.getWorldDirection(n);const pl=new THREE.Plane().setFromNormalAndCoplanarPoint(n,V3.target),p=new THREE.Vector3();return V3.ray.ray.intersectPlane(pl,p)?p:null;}
  let hovKey=null;
  function hoverPick(e){if(!V3.ok)return;const h=rayHit(e),k=h?h.object.userData.key:null;if(k!==hovKey){hovKey=k;V3.cv.title=k?INFO[k]?.n||k:'';V3.cv.style.cursor=k?'pointer':'grab';}}
  function pick(e){const h=rayHit(e);select(h?h.object.userData.key:null);}
  function select(k){V3.sel=k;LS.sel=k;if(k)snd('select');paintSel();info();labels();}
  function paintSel(){V3.parts.forEach(p=>p.grp.traverse(m=>{if(!m.isMesh||!m.material.emissive)return;m.material.emissive.setHex(p.key===V3.sel?0x7a5a12:0x000000);m.material.emissiveIntensity=p.key===V3.sel?.9:0;}));}
  function applyLook(){
    const ex=V3.explode;
    V3.parts.forEach(p=>{
      p.grp.position.copy(p.base).addScaledVector(p.dir,ex);
      let vis=!(p.hideWhen==='explode'&&ex>.12);
      if(V3.isolate&&V3.sel)vis=vis&&p.key===V3.sel;
      if(p.key==='cond'&&LS.sys==='chw')vis=false;
      p.grp.visible=vis;
      p.grp.traverse(m=>{if(!m.isMesh)return;const x=LS.xray&&p.casing;m.material.transparent=x||m.userData.baseTr;m.material.opacity=x?.12:m.userData.baseOp;m.material.depthWrite=!x;});
    });
  }
  function toolbar(){
    document.querySelectorAll('#lab3d [data-v3view]').forEach(b=>b.classList.toggle('on',b.dataset.v3view===V3.view));
    const tg={xray:LS.xray,labels:LS.labels,turn:LS.turntable,part:V3.particles,iso:V3.isolate};
    document.querySelectorAll('#lab3d [data-v3tog]').forEach(b=>b.classList.toggle('on',!!tg[b.dataset.v3tog]));
    const pj=$id('v3Proj');if(pj)pj.textContent=V3.proj==='persp'?'Perspective':'Orthographic';
  }
  function labels(){
    const L=$id('v3Labels');if(!L)return;
    if(!LS.labels){L.innerHTML='';return;}
    const keys=[...new Set(V3.parts.map(p=>p.key))].filter(k=>INFO[k]&&!(k==='cond'&&LS.sys==='chw'));
    L.innerHTML=keys.map(k=>`<div class="v3Lbl${k===V3.sel?' sel':''}" data-v3lbl="${k}">${esc(INFO[k].n)}</div>`).join('');
    L.querySelectorAll('[data-v3lbl]').forEach(d=>d.addEventListener('click',()=>{select(d.dataset.v3lbl);}));
  }
  /* label placement: project each anchor, then greedily drop labels that would overlap one already placed */
  const LBL_PRI=['coil','fan','comp','cond','oa','filter','vav','diff','sduct','cfans','panel','chiller','pump','vfd','heat','ret','curb','casing','sensor','pipe'];
  function moveLabels(){
    const L=$id('v3Labels');if(!L||!LS.labels)return;const w=V3.cv.clientWidth,h=V3.cv.clientHeight;
    const items=[];
    L.querySelectorAll('[data-v3lbl]').forEach(d=>{const k=d.dataset.v3lbl,p=V3.byKey[k]?.[0];if(!p||!p.grp.visible){d.style.display='none';return;}
      const v=p.anchor.clone().addScaledVector(p.dir,V3.explode).add(new THREE.Vector3(0,.6,0)).project(V3.cam);
      if(v.z>1||v.z<-1){d.style.display='none';return;}
      const x=(v.x+1)/2*w,y=(1-v.y)/2*h;d.style.display='';d.style.left=x.toFixed(1)+'px';d.style.top=y.toFixed(1)+'px';
      const pri=k===V3.sel?-1:(LBL_PRI.indexOf(k)<0?99:LBL_PRI.indexOf(k));items.push({d,x,y,pri,wd:d.offsetWidth||90,ht:d.offsetHeight||16});});
    items.sort((a,b)=>a.pri-b.pri);const placed=[];
    items.forEach(it=>{const r={l:it.x-it.wd/2-3,r:it.x+it.wd/2+3,t:it.y-it.ht-3,b:it.y+2};
      if(placed.some(q=>r.l<q.r&&r.r>q.l&&r.t<q.b&&r.b>q.t)){it.d.style.display='none';return;}placed.push(r);});
  }
  function info(){
    const host=$id('v3Info');if(!host)return;const k=V3.sel;
    const keys=[...new Set(V3.parts.map(p=>p.key))].filter(x=>INFO[x]&&!(x==='cond'&&LS.sys==='chw'));
    const list=`<div class="v3Parts">${keys.map(x=>`<button type="button" data-v3sel="${x}" class="${x===k?'on':''}">${esc(INFO[x].n.split(' ')[0])}${INFO[x].n.split(' ')[1]?' '+esc(INFO[x].n.split(' ')[1]):''}</button>`).join('')}</div>`;
    if(!k||!INFO[k]){host.innerHTML=`<h5>Select a component</h5><div class="sub">Click a part in the model or below. Double-click to orbit about it.</div>
      <p>The model is one rooftop unit of the ${unit().n} on this job (${unit().nom}-ton nominal; ${f0(unit().tons)} t design share), its supply drop and main, one VAV terminal and diffuser, and a zone sensor. Explode it to see how the parts stack along the airstream.</p>${list}`;}
    else{const I=INFO[k];host.innerHTML=`<h5>${esc(I.n)}</h5><div class="sub">${esc(I.g)} · live at ${String(LS.hour).padStart(2,'0')}:00</div><p>${esc(I.p)}</p>
      ${tbl([['Value'],['Now']],I.v().map(r=>[esc(r[0]),`<b>${esc(r[1])}</b>`]))}
      <p style="margin-top:8px"><b>Standards</b><br><small>${esc(I.std)}</small></p>
      <div style="display:flex;gap:6px;flex-wrap:wrap"><button class="hbtn" type="button" data-v3do="fit">Fit to part</button><button class="hbtn" type="button" data-v3do="iso">${V3.isolate?'Show all':'Isolate'}</button><button class="hbtn" type="button" data-v3do="clear">Clear</button></div>${list}`;}
    host.querySelectorAll('[data-v3sel]').forEach(b=>b.addEventListener('click',()=>select(b.dataset.v3sel)));
    host.querySelectorAll('[data-v3do]').forEach(b=>b.addEventListener('click',()=>{const d=b.dataset.v3do;if(d==='fit')fit([V3.sel]);if(d==='iso'){V3.isolate=!V3.isolate;toolbar();info();}if(d==='clear'){V3.isolate=false;select(null);}}));
  }
  function syncExplode(){const s=$id('v3Ex');if(s)s.value=LS.explode;}
  function render3D(light){
    const host=$id('lab3d');
    if(!host.dataset.built){
      host.dataset.built='1';
      host.innerHTML=`<div class="lab3dWrap"><div id="lab3dView">
          <div class="v3Bar">${[['iso3','3D'],['axo','Axonometric'],['top','Plan'],['front','Front'],['right','Right'],['back','Back'],['left','Left']].map(([k,t])=>`<button type="button" data-v3view="${k}">${t}</button>`).join('')}<span class="sep"></span>
            <button type="button" data-v3tog="xray">X-ray</button><button type="button" data-v3tog="labels">Labels</button><button type="button" data-v3tog="part">Flow</button><button type="button" data-v3tog="turn">Turntable</button><button type="button" data-v3tog="iso">Isolate</button><button type="button" data-v3do2="home">⌂ Home</button><button type="button" data-v3do2="fit">Fit</button><button type="button" id="v3Proj" data-v3do2="proj">Perspective</button></div>
          <div class="vcWrap"><div class="vc" id="vcCube"><div data-vc="front" style="transform:translateZ(35px)">FRONT</div><div data-vc="back" style="transform:rotateY(180deg) translateZ(35px)">BACK</div><div data-vc="right" style="transform:rotateY(90deg) translateZ(35px)">RIGHT</div><div data-vc="left" style="transform:rotateY(-90deg) translateZ(35px)">LEFT</div><div data-vc="top" style="transform:rotateX(90deg) translateZ(35px)">TOP</div><div data-vc="bottom" style="transform:rotateX(-90deg) translateZ(35px)">BOTTOM</div></div>
            <div class="vcHome"><button type="button" data-v3do2="home" title="Home view">⌂</button><button type="button" data-v3view="axo" title="Axonometric">ISO</button></div></div>
          <div class="v3Labels" id="v3Labels"></div>
          <div class="v3Explode">Assembled<input type="range" id="v3Ex" min="0" max="1" step=".01" value="${LS.explode}" aria-label="Explode">Exploded<button type="button" class="hbtn" data-v3do2="explodeAnim" style="padding:2px 8px">▶</button></div>
          <div class="v3Hint">Drag: orbit · right-drag or Shift-drag: pan · wheel: zoom to cursor · double-click: orbit about a part · keys H F A P T E X L</div>
        </div><div class="labCard" id="v3Info" style="margin:0;overflow:auto;max-height:calc(100vh - 150px)"></div></div>`;
      const view=$id('lab3dView');
      if(!init3D(view))return;
      view.addEventListener('click',e=>{
        const v=e.target.closest('[data-v3view]');if(v){goView(v.dataset.v3view);return;}
        const c=e.target.closest('[data-vc]');if(c){goView(c.dataset.vc);return;}
        const t=e.target.closest('[data-v3tog]');if(t){const k=t.dataset.v3tog;if(k==='xray')LS.xray=!LS.xray;if(k==='labels'){LS.labels=!LS.labels;labels();}if(k==='turn')LS.turntable=!LS.turntable;if(k==='part')V3.particles=!V3.particles;if(k==='iso')V3.isolate=!V3.isolate;toolbar();info();return;}
        const d=e.target.closest('[data-v3do2]');if(d){const k=d.dataset.v3do2;if(k==='home')home();if(k==='fit')fit(V3.sel?[V3.sel]:null);if(k==='proj'){V3.proj=V3.proj==='persp'?'ortho':'persp';V3.view='free';placeCam();toolbar();}
          if(k==='explodeAnim'){V3.exAnim={t0:performance.now()};}}
      });
      $id('v3Ex').addEventListener('input',e=>{LS.explode=+e.target.value;V3.exAnim=null;});
      goView('iso3',true);info();toolbar();
    }
    if(!V3.ok)return;
    if(rebuild3D){rebuild();info();}
    if(!light)info();
    start3D();
  }
  function start3D(){if(V3.raf||isJsdom)return;const loop=t=>{V3.raf=0;if(!LS.open||LS.section!=='3d'||document.hidden)return;frame(t);V3.raf=requestAnimationFrame(loop);};V3.raf=requestAnimationFrame(loop);}
  const ease=x=>x<.5?2*x*x:1-Math.pow(-2*x+2,2)/2;
  function frame(t){
    const dt=Math.min(.05,(t-V3.last)/1000);V3.last=t;
    if(V3.anim){const a=V3.anim,k=cl((t-a.t0)/a.dur,0,1),e=ease(k);V3.theta=a.from.th+(a.to.th-a.from.th)*e;V3.phi=a.from.ph+(a.to.ph-a.from.ph)*e;
      if(a.to.tg){V3.target.lerpVectors(a.from.tg,a.to.tg,e);V3.dist=a.from.d+(a.to.d-a.from.d)*e;}if(k>=1)V3.anim=null;}
    if(LS.turntable)V3.theta+=dt*.25;
    if(V3.exAnim){const k=((t-V3.exAnim.t0)/4200)%1;LS.explode=k<.5?ease(k*2):ease((1-k)*2);syncExplode();if(t-V3.exAnim.t0>4200)V3.exAnim=null;}
    V3.explode+=(LS.explode-V3.explode)*Math.min(1,dt*7);
    applyLook();
    const P=plant();
    V3.parts.forEach(p=>p.spin.forEach(([o,ax,kind])=>{const sp=kind==='fan'?P.flow*9:(P.stages?6:0);o.rotation[ax]+=dt*sp;}));
    const showF=V3.particles&&V3.explode<.12;
    V3.air.visible=showF;V3.ref.visible=showF&&LS.sys==='dx'&&P.stages>0;
    if(showF){const step=(pts,path,speed)=>{const a=pts.geometry.attributes.position.array;pts.userData.seed.forEach((sd,i)=>{sd[0]=(sd[0]+dt*speed)%1;const q=pathAt(path,sd[0]);a[i*3]=q[0];a[i*3+1]=q[1]+sd[1]*1.2;a[i*3+2]=q[2]+sd[1]*2.2;});pts.geometry.attributes.position.needsUpdate=true;};
      step(V3.air,AIRPATH,.05+.07*P.flow);if(V3.ref.visible)step(V3.ref,REFPATH,.08*(P.stages/P.stagesMax)+.02);}
    placeCam();
    V3.r.render(V3.sc,V3.cam);
    moveLabels();
  }

  /* ================================================================ open / close & entry points */
  function open(sec){
    shell();LS.open=true;LS.hour=H()?.HV?.hour??LS.hour;
    $id('labPage').classList.add('on');document.documentElement.style.overflow='hidden';
    setSection(sec||LS.section);
    setTimeout(()=>{V3.resize();render();},60);
  }
  function close(){LS.open=false;$id('labPage')?.classList.remove('on');document.documentElement.style.overflow='';cancelAnimationFrame(phRAF);if(playT){clearInterval(playT);playT=null;}}
  try{
    shell();
    window.addEventListener('resize',()=>{if(LS.open){V3.resize();}});
    on('model:recalc',()=>{if(LS.open){rebuild3D=LS.section==='3d';render(true);}});
    on('sim:day',()=>{if(LS.open&&(LS.section==='cx'))render(true);});
    /* header: Model menu */
    const mm=document.querySelector('#menuModel .artMenuPanel');
    if(mm){const l=document.createElement('div');l.className='artMenuLabel';l.textContent='Explain the system';mm.appendChild(l);
      const b=document.createElement('button');b.className='hbtn';b.type='button';b.id='btnSystemLab';b.textContent='⚙ System Lab (3D · cycles · power · Cx)';b.addEventListener('click',()=>open('3d'));mm.appendChild(b);}
    /* story page */
    const nt=$id('btnNarrativeEnter');
    if(nt){const b=document.createElement('button');b.className='narTopButton';b.type='button';b.id='btnNarLab';b.textContent='System Lab';b.addEventListener('click',()=>open('3d'));nt.parentElement.insertBefore(b,nt);}
    /* HVAC Performance tab */
    const hv=$id('tHVAC')?.querySelector('.hvCtl');
    if(hv){const b=document.createElement('button');b.className='hbtn';b.type='button';b.textContent='⚙ System Lab';b.addEventListener('click',()=>open('flow'));hv.appendChild(b);}
    const cmds=window.ARTEMIS_COMMANDS;
    if(Array.isArray(cmds)){
      SECS.forEach(([k,t,s])=>cmds.push({title:`System Lab · ${t}`,group:'System Lab',run:()=>open(k),keywords:'explain working principle '+s+' commissioning compatibility electrical amps voltage refrigerant cycle exploded axonometric orbit'}));
    }
    window.ARTEMIS_LAB={state:LS,open,close,section:setSection,unit,op,plant,cycle,psat,tsat,hf,hg,electrical,duty,compat,cxStatus,CX,V3,views:VIEWS,goView,select,fit,
      explodeNow:v=>{LS.explode=v;V3.explode=v;if(V3.ok){applyLook();}}};
    mark('P49');
  }catch(err){warn('P49',err);}
  window.ARTEMIS_PATCHES=(window.ARTEMIS_PATCHES||[]).concat([{version:PATCH,applied}]);
})();
